-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 18, 2017 at 01:09 PM
-- Server version: 10.1.9-MariaDB
-- PHP Version: 5.6.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `ultimatecms_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `addinfowithajax_tb`
--

CREATE TABLE `addinfowithajax_tb` (
  `id` int(5) NOT NULL,
  `field1` text NOT NULL,
  `field2` text NOT NULL,
  `field3` text NOT NULL,
  `field4` text NOT NULL,
  `field5` text NOT NULL,
  `field6` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `addinfowithfile_tb`
--

CREATE TABLE `addinfowithfile_tb` (
  `id` int(5) NOT NULL,
  `field1` text NOT NULL,
  `file1` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `addinfowithoutajax_tb`
--

CREATE TABLE `addinfowithoutajax_tb` (
  `id` int(5) NOT NULL,
  `field1` text NOT NULL,
  `field2` text NOT NULL,
  `field3` text NOT NULL,
  `field4` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `adminloginlog_tbl`
--

CREATE TABLE `adminloginlog_tbl` (
  `id` int(5) NOT NULL,
  `loggedinusername` text NOT NULL,
  `relatedinfo` text NOT NULL,
  `dateoflogin` text NOT NULL,
  `loginusing` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `admin_tbl`
--

CREATE TABLE `admin_tbl` (
  `id` int(5) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin_tbl`
--

INSERT INTO `admin_tbl` (`id`, `username`, `password`) VALUES
(1, 'admin', 'admin123');

-- --------------------------------------------------------

--
-- Table structure for table `events_tbl`
--

CREATE TABLE `events_tbl` (
  `id` int(5) NOT NULL,
  `title` text NOT NULL,
  `start` date NOT NULL,
  `end` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `location_tb`
--

CREATE TABLE `location_tb` (
  `id` int(5) NOT NULL,
  `field1` text NOT NULL,
  `field2` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `multiimage_tb`
--

CREATE TABLE `multiimage_tb` (
  `id` int(5) NOT NULL,
  `multiimg` text NOT NULL,
  `fieldid` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `multiplevalue_tb`
--

CREATE TABLE `multiplevalue_tb` (
  `id` int(5) NOT NULL,
  `multifield` text NOT NULL,
  `fieldid` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `requestforaccount_tb`
--

CREATE TABLE `requestforaccount_tb` (
  `id` int(5) NOT NULL,
  `name` text NOT NULL,
  `email` text NOT NULL,
  `mobile` text NOT NULL,
  `message` text NOT NULL,
  `request_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addinfowithajax_tb`
--
ALTER TABLE `addinfowithajax_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addinfowithfile_tb`
--
ALTER TABLE `addinfowithfile_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addinfowithoutajax_tb`
--
ALTER TABLE `addinfowithoutajax_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `adminloginlog_tbl`
--
ALTER TABLE `adminloginlog_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events_tbl`
--
ALTER TABLE `events_tbl`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `location_tb`
--
ALTER TABLE `location_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `multiimage_tb`
--
ALTER TABLE `multiimage_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `multiplevalue_tb`
--
ALTER TABLE `multiplevalue_tb`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `requestforaccount_tb`
--
ALTER TABLE `requestforaccount_tb`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addinfowithajax_tb`
--
ALTER TABLE `addinfowithajax_tb`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `addinfowithfile_tb`
--
ALTER TABLE `addinfowithfile_tb`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `addinfowithoutajax_tb`
--
ALTER TABLE `addinfowithoutajax_tb`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `adminloginlog_tbl`
--
ALTER TABLE `adminloginlog_tbl`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `admin_tbl`
--
ALTER TABLE `admin_tbl`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `events_tbl`
--
ALTER TABLE `events_tbl`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `location_tb`
--
ALTER TABLE `location_tb`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `multiimage_tb`
--
ALTER TABLE `multiimage_tb`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `multiplevalue_tb`
--
ALTER TABLE `multiplevalue_tb`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `requestforaccount_tb`
--
ALTER TABLE `requestforaccount_tb`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;