<?php
require '../webconfig/config.php';


  $id  = $_POST["id"];
  $post = $_POST;

  $sql = "UPDATE `addinfowithajax_tb` SET field1 = '".$post['title']."'

    ,field2 = '".$post['description']."' 

    WHERE id = '".$id."'";

  $result = $conn->query($sql);


  $sql = "SELECT * FROM `addinfowithajax_tb` WHERE id = '".$id."'"; 

  $result = $conn->query($sql);

  $data = $result->fetch_assoc();


echo json_encode($data);
?>