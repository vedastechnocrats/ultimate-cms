<?php

require '../webconfig/config.php';

 $id  = $_POST["id"];

 $sql = "DELETE FROM `addinfowithajax_tb` WHERE id = '".$id."'";

 $result = $conn->query($sql);

 echo json_encode([$id]);
 
?>