<!--Add Header Web Part Here-->
<?php include('webparts/header.php'); ?>
<!---->	

<!--Add Sidebar Web Part Here-->
<?php include('webparts/sidebar.php'); ?>
<!---->	
	  
<!--Website Content goes here-->  
	  
      <div class="site-content">
        <div class="row">
          <div class="col-sm-12">
            <div class="panel panel-default m-b-0">
              <div class="panel-heading">
                <h3 class="m-y-0">Calendar</h3>
              </div>
              <div class="panel-body">
                <div id="calendar"></div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
      <!---->
	  
<!--Add Footer Web Part Here-->
<?php include('webparts/footer.php'); ?>
<!---->