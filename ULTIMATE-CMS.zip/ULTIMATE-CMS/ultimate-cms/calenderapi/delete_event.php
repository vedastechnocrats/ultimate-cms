<?php

$id = $_POST['id'];

try {
	require "../webconfig/config.php";
} catch(Exception $e) {
	exit('Unable to connect to database.');
}

$sql = "DELETE from events_tbl WHERE id=".$id;
$q = $db_con->prepare($sql);
$q->execute();

?>