<?php

 $json = array();

 $requete = "SELECT * FROM events_tbl ORDER BY id";

 try {
 	require "../webconfig/config.php";
 } catch(Exception $e) {
    exit('Unable to connect to database.');
 }

 $resultat = $db_con->query($requete) or die(print_r($db_con->errorInfo()));

 echo json_encode($resultat->fetchAll(PDO::FETCH_ASSOC));

?>