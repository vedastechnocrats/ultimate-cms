<?php

require('webconfig/config.php');

//Check Either We are getting value using post method or not
if($_POST)
 {
	 //Get all the value using POST Method
	 $filewithvalue1=$_POST['filewithvalue1'];
	 //
	 
	 //Get Uploaded File Details
	$name = $_FILES['file']['name'];
	
	//Rename the file to the microtime so that wont get overwrite by same name file
	$temp = explode(".", $_FILES['file']['name']);
    $newfilename = round(microtime(true)) . '.' . end($temp);
	 
	 //Exeception Handling Try the SQl to execute if it is correct everything inside try will happen
	 try {
	 //Prepare the SQL Statement
	 $stmt = $db_con->prepare("INSERT INTO `addinfowithfile_tb`(`field1`, `file1`) 
	 VALUES (:filewithvalue1,:newfilename)");
	   
	 //Bind all the variables into parameter to store the data
	   $stmt->bindParam(":filewithvalue1",$filewithvalue1);
	   $stmt->bindParam(":newfilename",$newfilename);
	   
   
     //Execute and check execution success or not
		if($stmt->execute())
		{
			//Execution Success do something 
			
			//Copy the file to physical path
			move_uploaded_file($_FILES['file']['tmp_name'], './uploadedfiles/'.$newfilename);
			
			//Get the ID of the Inserted Data
			$last_id = $db_con->lastInsertId();
			
			
			//Multiple file upload || Loop through files using foreach
			foreach($_FILES['files']['tmp_name'] as $key => $tmp_name ){
		    
			//Take Each files using a key
			$file_name = $key.$_FILES['files']['name'][$key];
		    $file_tmp =$_FILES['files']['tmp_name'][$key];
			
			//Get the file name without extension_loaded
			$actualname=basename($file_name);
			
			//Assign the folder name
            $folder="uploadedfiles";
        
		    $temporary = explode(".", $file_name);
            $thenewfilename = $actualname.round(microtime(true)) . '.' . end($temporary);

		    $savedimage=$folder."/".$thenewfilename;
			
			
			try{
		//Insert data
				$stmt1 = $db_con->prepare("INSERT INTO `multiimage_tb`(`multiimg`, `fieldid`) 
				VALUES (:simg,:lsid)");
											   
				//Put Variables into a sanitize version
					$stmt1->bindParam(":simg",$savedimage);
					$stmt1->bindParam(":lsid",$last_id);
					if($stmt1->execute()){
					$desired_dir=$folder;
        
                move_uploaded_file($file_tmp,"$desired_dir/".$thenewfilename);
								}
										
		}catch(PDOException $e){
			echo "A problem occured :" .$e->getMessage();
		}
			
			
			}
            //Multiple File Upload End   
			
			//Redirect the page where the value is submitted with a variable status and set the value success
			header("location: $base_url/addvalue/?status=uploadsuccess");
			
		}else{
			//Execution Failed do something 
		}
	 }
	 //SQl Or Database Configuration is not correct
	 //Store the exeception message in a variable
	 catch(PDOException $ex){
		 //Printout the error message
		echo "A problem occured :" .$ex->getMessage(); 
	 }
		
		
 }else{
	 echo "No Value from Post Method";
 }


?>