<?php
require_once 'webconfig/config.php';

session_start();//session is a way to store information (in variables) to be used across multiple pages.  
session_destroy(); 

setcookie("ucadminusername", "", -1,'/');
setcookie("ucadminpassword", "", -1,'/');

header("location: $base_url/login/?status=logoutsuccess");
?>