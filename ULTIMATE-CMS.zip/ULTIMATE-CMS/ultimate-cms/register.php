<?php require ('webconfig/config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description" content="">
    <title>Ultimate CMS</title>
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.html">
    <link rel="icon" type="image/png" href="<?php echo $base_url; ?>/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="<?php echo $base_url; ?>/favicon-16x16.png" sizes="16x16">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700" rel="stylesheet">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/vendor.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/cosmos.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/application.min.css">
  </head>
  <body class="authentication-body">
    <div class="container-fluid">
      <div class="authentication-header m-b-30">
        <div class="clearfix">
          <div class="pull-left">
            <a class="authentication-logo" href="<?php echo $base_url; ?>/">
              <img src="<?php echo $base_url; ?>/img/logo.png" alt="" height="25">
              <span>Ultimate CMS</span>
            </a>
          </div>
          <div class="pull-right">
            <a href="<?php echo $base_url; ?>/login/" class="btn btn-outline-info">Login</a>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-6 col-sm-offset-3">
		
          <div class="authentication-content m-b-30">
            <h3 class="m-b-30">Get A Ultimate CMS Account</h3>
			<p>Fillup this form we will contact you shortly</p>
			<!--This is the success message only visible if the data successfully inserted via ajax-->
			<div id="success-alert1" style="display:none;">
			<div class="alert alert-success alert-dismissable" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">
                      <i class="zmdi zmdi-close"></i>
                    </span>
                  </button>
                  <span class="alert-icon">
                    <i class="zmdi zmdi-check"></i>
                  </span>
                  <strong>Congratulations!</strong> We got your message. We will get in touch with you shortly
                </div>
			</div>
            <!---->
			
			<!--This is the failed message only visible if the data failed to insert via ajax-->
			<div id="failed-alert1" style="display:none;">
			<div class="alert alert-danger alert-dismissable" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">
                      <i class="zmdi zmdi-close"></i>
                    </span>
                  </button>
                  <span class="alert-icon">
                    <i class="zmdi zmdi-close-circle-o"></i>
                  </span>
                  <strong>Oh snap!</strong> Change a few things up and try submitting again.
                </div>
			</div>
			<!---->
            <form id="using-ajax" method="post">
			  <div class="form-group">
                <label for="form-control-2">Name</label>
                <input type="text" class="form-control" id="form-control-2" placeholder="Jon Snow" id="ajax-value1" name="ajax-value1">
              </div>
              <div class="form-group">
                <label for="form-control-1">Email</label>
                <input type="email" class="form-control" id="form-control-1" placeholder="email@example.com" id="ajax-value2" name="ajax-value2">
              </div>
			  <div class="form-group">
                <label for="form-control-1">Mobile</label>
                <input type="number" class="form-control" id="form-control-1" placeholder="9988776655" id="ajax-value3" name="ajax-value3">
              </div>
              <div class="form-group">
                <label for="form-control-2">Message</label>
                <textarea class="form-control" id="form-control-2" id="ajax-value4" name="ajax-value4"></textarea>
              </div>
              <div class="form-group">
                <label class="switch switch-info">
                  <input type="checkbox" name="newsletter" class="s-input" checked="checked">
                  <span class="s-content">
                    <span class="s-track"></span>
                    <span class="s-handle"></span>
                  </span>
                  <span class="s-desc text-muted">Get the hottest industry content straight to your inbox.</span>
                </label>
              </div>
              <div class="clearfix">
                <div class="pull-right">
                  <button type="submit" class="btn btn-info btn-labeled" id="submit-button">Next
                    <span class="btn-label btn-label-right">
                      <i class="zmdi zmdi-chevron-right p-x-5"></i>
                    </span>
                  </button>
				  
				  <a href="Javascript:;" class="btn btn-info btn-labeled" style="display:none" id="loading-button" >Loading
				  <span class="btn-label btn-label-right">
				  <i class="fa fa-spinner fa-spin" aria-hidden="true"></i> 
				  </span>
				  </a>
				  
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="authentication-footer">
        <span class="text-muted">Need help? Contact us <a href="mailto:support@ultimate-cms.in" target="_blank">support@ultimate-cms.in</a></span>
      </div>
    </div>
    <script src="<?php echo $base_url; ?>/js/vendor.min.js"></script>
    <script src="<?php echo $base_url; ?>/js/cosmos.min.js"></script>
    <script src="<?php echo $base_url; ?>/js/application.min.js"></script>
	<!--AJAX Method to Insert Data of fisrt Form-->
	<script>
	$(document).ready(function () {
		 $('#using-ajax').submit(function (event) {
			 event.preventDefault();
			 $('#submit-button').css("display", "none");
			 $('#loading-button').css("display", "inline-block");
			 var form = $(this);
			 var formData = form.serialize();
			 
			 
			 $.ajax({
			 url: '<?php echo $base_url; ?>/executablefiles/addregvalue1_exec.php',
			 method: 'POST',
			 data: formData,
			 success: function (data) { 
			 $('#submit-button').css("display", "block");
			 $('#loading-button').css("display", "none");
				 $('#success-alert1').css("display", "block").delay(10000).slideUp(300);
				 $("#using-ajax")[0].reset();
				 },
				 error:function (xhr, ajaxOptions, thrownError){
					 $('#submit-button').css("display", "block");
					 $('#loading-button').css("display", "none");
                $('#failed-alert1').css("display", "block").delay(10000).slideUp(300);
				$("#using-ajax")[0].reset();
                alert(thrownError);
            }
			 });
		 });
	});
</script>
	<!-- -->
  </body>

</html>