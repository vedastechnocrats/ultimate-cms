<?php require ('webconfig/config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description" content="">
    <title>Ultimate CMS</title>
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.html">
    <link rel="icon" type="image/png" href="<?php echo $base_url; ?>/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="<?php echo $base_url; ?>/favicon-16x16.png" sizes="16x16">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/vendor.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/cosmos.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/application.min.css">
  </head>
  <body class="authentication-body">
    <div class="container-fluid">
      <div class="authentication-header m-b-30">
        <div class="clearfix">
          <div class="pull-left">
            <a class="authentication-logo" href="<?php echo $base_url; ?>/">
              <img src="<?php echo $base_url; ?>/img/logo.png" alt="" height="25">
              <span>Ultimate CMS</span>
            </a>
          </div>
          <div class="pull-right">
            <a href="<?php echo $base_url; ?>/login/" class="btn btn-outline-info">Login</a>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-4 col-sm-offset-4">
          <div class="authentication-content m-b-30">
            <h3 class="m-t-0 m-b-30 text-center">Find your Password</h3>
			
			<!--This is the success message only visible if the data successfully inserted via ajax-->
			<div id="success-alert1" style="display:none;">
			<div class="alert alert-success alert-dismissable" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">
                      <i class="zmdi zmdi-close"></i>
                    </span>
                  </button>
                  <span class="alert-icon">
                    <i class="zmdi zmdi-check"></i>
                  </span>
                  <strong>Congratulations!</strong> We got your Request. We will send your password shortly
                </div>
			</div>
            <!---->
			
			<!--This is the failed message only visible if the data failed to insert via ajax-->
			<div id="failed-alert1" style="display:none;">
			<div class="alert alert-danger alert-dismissable" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">
                      <i class="zmdi zmdi-close"></i>
                    </span>
                  </button>
                  <span class="alert-icon">
                    <i class="zmdi zmdi-close-circle-o"></i>
                  </span>
                  <strong>Oh snap!</strong> Change a few things up and try submitting again.
                </div>
			</div>
			<!---->
			
            <form method="post" id="ajax-mailsend">
              <div class="form-group">
                <label for="form-control-1">Email address</label>
                <input type="email" class="form-control" id="email" name="email" placeholder="Email">
              </div>
			  
			      <button type="submit" class="btn btn-info btn-block" id="submit-button">Submit
                  </button>
				  
				  <a href="Javascript:;" class="btn btn-info btn-labeled" style="display:none" id="loading-button" >Loading
				  <span class="btn-label btn-label-right">
				  <i class="fa fa-spinner fa-spin" aria-hidden="true"></i> 
				  </span>
				  </a>
			  
              
            </form>
          </div>
        </div>
      </div>
      <div class="authentication-footer">
        <span class="text-muted">Need help? Contact us <a href="mailto:support@ultimate-cms.in" target="_blank">support@ultimate-cms.in</a></span>
      </div>
    </div>
    <script src="<?php echo $base_url; ?>/js/vendor.min.js"></script>
    <script src="<?php echo $base_url; ?>/js/cosmos.min.js"></script>
    <script src="<?php echo $base_url; ?>/js/application.min.js"></script>
	<script>
	$(document).ready(function () {
		 $('#ajax-mailsend').submit(function (event) {
			 event.preventDefault();
			 $('#submit-button').css("display", "none");
			 $('#loading-button').css("display", "inline-block");
			 var form = $(this);
			 var formData = form.serialize();
			 
			 
			 $.ajax({
			 url: '<?php echo $base_url; ?>/executablefiles/forgetpassword_exec.php',
			 method: 'POST',
			 data: formData,
			 success: function (data) { 
			 $('#submit-button').css("display", "block");
			 $('#loading-button').css("display", "none");
				 $('#success-alert1').css("display", "block").delay(10000).slideUp(300);
				 $("#using-ajax")[0].reset();
				 },
				 error:function (xhr, ajaxOptions, thrownError){
					 $('#submit-button').css("display", "block");
					 $('#loading-button').css("display", "none");
                $('#failed-alert1').css("display", "block").delay(10000).slideUp(300);
				$("#using-ajax")[0].reset();
                alert(thrownError);
            }
			 });
		 });
	});
</script>
  </body>

</html>