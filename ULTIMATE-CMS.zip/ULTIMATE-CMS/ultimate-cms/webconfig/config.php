<?php
//This will hide all the errors and warnings in the applications (Activate it when the application is ready to release)
/*error_reporting(0);*/

// Base URL of the application (Replace it with the domain name or the new location or folder name)
$base_url="http://localhost/ultimate-cms";

//Database Connections

//Connections Variables
/*Server or Host Name*/
$databasehost = 'localhost';
/*Database Name*/
$databasename = 'ultimatecms_db';
/*Database Username who has all previledges to manipulate the specified database*/
$databaseuser = 'root';
/*Password of the specified Username*/
$databasepass = '';
/*Any Prefix (If Required)*/
$prefix = '';

//PHP PDO Connections
try{$db_con = new PDO("mysql:host={$databasehost};dbname={$databasename}",$databaseuser,$databasepass);
$db_con->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}catch(PDOException $ex){die($ex->getMessage());}
/*Use $db_con in all connections implemented through php pdo*/

//PHP POP Connections (Soon going to deprecated)
$bd = mysql_connect($databasehost, $databaseuser, $databasepass) or die("Could not connect database");
mysql_select_db($databasename, $bd) or die("Could not select database");
/*Use $bd in all connections implemented through php pop*/

//PHP OOP Connection
$conn = new mysqli($databasehost, $databaseuser, $databasepass, $databasename);
if ($conn->connect_error) {die("Connection failed: " . $conn->connect_error);}
/*Use $conn in all connections implemented through php oop*/


//Set the timezone as per the need, find here http://php.net/manual/en/timezones.php
date_default_timezone_set('Asia/Calcutta');

//Any User Defined Functions Goes Here
/*Function to generate before and after */
function after ($this, $inthat)
    {
        if (!is_bool(strpos($inthat, $this)))
        return substr($inthat, strpos($inthat,$this)+strlen($this));
    };

    function after_last ($this, $inthat)
    {
        if (!is_bool(strrevpos($inthat, $this)))
        return substr($inthat, strrevpos($inthat, $this)+strlen($this));
    };

    function before ($this, $inthat)
    {
        return substr($inthat, 0, strpos($inthat, $this));
    };

    function before_last ($this, $inthat)
    {
        return substr($inthat, 0, strrevpos($inthat, $this));
    };

    function between ($this, $that, $inthat)
    {
        return before ($that, after($this, $inthat));
    };

    function between_last ($this, $that, $inthat)
    {
     return after_last($this, before_last($that, $inthat));
    };

// use strrevpos function in case your php version does not include it
function strrevpos($instr, $needle)
{
    $rev_pos = strpos (strrev($instr), strrev($needle));
    if ($rev_pos===false) return false;
    else return strlen($instr) - $rev_pos - strlen($needle);
};
/**/
?>