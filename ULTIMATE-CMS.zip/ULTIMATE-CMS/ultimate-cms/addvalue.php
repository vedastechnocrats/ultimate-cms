<!--Add Header Web Part Here-->
<?php include('webparts/header.php'); ?>
<!---->	

<!--Add Sidebar Web Part Here-->
<?php include('webparts/sidebar.php'); ?>
<!---->	




<!--Website Content goes here-->  
    <div class="site-content">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Add Information</h3>
          </div>
		  
		  
		  <!--Get the value from URL and set it to a variable to check whether execution is successful or not-->
<?php
//put a @ symbol before the line so that it cant throw a value cant find error on that line
//@ Only hide the warning it doesnot resolve it
@$status=$_GET['status'];
if($status=="success"){
	//url have the value success which means execution is a success show a success message here 
	?>
	<button type="button" style="display:none;" id="statusmodal" class="btn btn-outline-success m-w-120" data-toggle="modal" data-target="#successModal">Success</button>
                
	                <div id="successModal" class="modal fade" tabindex="-1" role="dialog">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">
                            <i class="zmdi zmdi-close"></i>
                          </span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="text-center">
                          <div class="text-success">
                            <i class="zmdi zmdi-check zmdi-hc-5x"></i>
                          </div>
                          <h3>Success</h3>
                          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            <br>Pellentesque lacinia non massa a euismod.</p>
                          <div class="m-y-30">
                            <button type="button" data-dismiss="modal" class="btn btn-success">Continue</button>
                            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer"></div>
                    </div>
                  </div>
                </div>
				<?php
}else if($status=="failed"){
	//url have the value success which means execution is a success show a success message here 
	?>
	<button type="button" style="display:none;" id="statusmodal" class="btn btn-outline-success m-w-120" data-toggle="modal" data-target="#dangerModal">Failed</button>
    
	                <div id="dangerModal" class="modal fade" tabindex="-1" role="dialog">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">
                            <i class="zmdi zmdi-close"></i>
                          </span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="text-center">
                          <div class="text-danger">
                            <i class="zmdi zmdi-alert-triangle zmdi-hc-5x"></i>
                          </div>
                          <h3>Danger</h3>
                          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            <br>Pellentesque lacinia non massa a euismod.</p>
                          <div class="m-y-30">
                            <button type="button" data-dismiss="modal" class="btn btn-danger">Continue</button>
                            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer"></div>
                    </div>
                  </div>
                </div>
				<?php
}else if($status=="uploadsuccess"){
?>
<button type="button" style="display:none;" id="statusmodal" class="btn btn-outline-success m-w-120" data-toggle="modal" data-target="#successModal2">Upload Success</button>
    
                <div id="successModal2" class="modal fade" tabindex="-1" role="dialog">
                  <div class="modal-dialog">
                    <div class="modal-content bg-success">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">
                            <i class="zmdi zmdi-close"></i>
                          </span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="text-center">
                          <div>
                            <i class="zmdi zmdi-check zmdi-hc-5x"></i>
                          </div>
                          <h3>Success</h3>
                          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            <br>Pellentesque lacinia non massa a euismod.</p>
                          <div class="m-y-30">
                            <button type="button" data-dismiss="modal" class="btn btn-default">Continue</button>
                            <button type="button" data-dismiss="modal" class="btn btn-success">Close</button>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer"></div>
                    </div>
                  </div>
                </div>






<?php
}
?>
<!-- -->
		  
		  
          <div class="panel-body">
            <div class="row">
			<div class="col-md-12">
			
			<!--This is the success message only visible if the data successfully inserted via ajax-->
			<div id="success-alert1" style="display:none;">
			<div class="alert alert-success alert-dismissable" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">
                      <i class="zmdi zmdi-close"></i>
                    </span>
                  </button>
                  <span class="alert-icon">
                    <i class="zmdi zmdi-check"></i>
                  </span>
                  <strong>Well done!</strong> You successfully read this important alert message.
                </div>
			</div>
            <!---->
			
			<!--This is the failed message only visible if the data failed to insert via ajax-->
			<div id="failed-alert1" style="display:none;">
			<div class="alert alert-danger alert-dismissable" role="alert">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">
                      <i class="zmdi zmdi-close"></i>
                    </span>
                  </button>
                  <span class="alert-icon">
                    <i class="zmdi zmdi-close-circle-o"></i>
                  </span>
                  <strong>Oh snap!</strong> Change a few things up and try submitting again.
                </div>
			</div>
			<!---->
			
			
			<!--Change the form ID according to the relevance-->
             <form class="form-horizontal" id="using-ajax" method="post" >
			    <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-5">Placeholder Input</label>
                    <div class="col-sm-9">
                      <input id="ajax-value1" name="ajax-value1" class="form-control" type="email" placeholder="Placeholder input text"  required>
                    </div>
                </div>
				<div class="form-group">
                    <label class="col-sm-3 control-label">Checkboxes and radios</label>
                    <div class="col-sm-9">
                      <div class="radio">
                        <label>
                          <input type="radio" name="ajax-value3" value="day"> Day
                        </label>
                      </div>
                      <div class="radio">
                        <label>
                          <input type="radio" name="ajax-value3" value="week" checked="checked"> Week
                        </label>
                      </div>
                      <div class="radio">
                        <label>
                          <input type="radio" name="ajax-value3" value="month"> Month
                        </label>
                      </div>
					  <div class="checkbox">
                        <label>
                          <input type="checkbox" name="ajax-value4" checked="checked" required> Keep me signed in
                        </label>
                      </div>
                    </div>
                </div>
				<div class="form-group">
                <label for="form-control-1" class="col-sm-3  control-label">Single select box</label>
                <div class="col-md-9">
                  <select id="ajax-value5"  name="ajax-value5" class="form-control" data-plugin="select2" data-options="{ theme: bootstrap }">
                    <option value="option1">HTML</option>
                    <option value="option2">CSS</option>
                    <option value="option3">Javascript</option>
                    <option value="option4">PHP</option>
                    <option value="option5">Bootstrap</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label for="form-control-1" class="col-sm-3  control-label">Multiple select box</label>
                <div class="col-md-9">
                  <select id="ajax-value6" class="form-control" name="ajax-value6[]" data-plugin="select2" multiple="multiple">
                    <option value="option1">HTML</option>
                    <option value="option2">CSS</option>
                    <option value="option3">Javascript</option>
                    <option value="option4">PHP</option>
                    <option value="option5">Bootstrap</option>
                  </select>
                </div>
              </div>
			  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-5">Date Picker</label>
                    <div class="col-sm-9">
                      <input class="form-control datepicker_recurring_start" name="ajax-value7" id="ajax-value7" type="text" placeholder="Placeholder input text">
                    </div>
                </div>
				<div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-5">Time Picker</label>
                    <div class="col-sm-9">
                      <input class="form-control timepicker_recurring_start" type="text" name="ajax-value8" id="ajax-value8" placeholder="Placeholder input text">
                    </div>
                </div>
				<div class="form-group">
                    <div class="col-md-offset-3 col-sm-9">
                     <button type="submit" class="btn btn-primary m-w-120" id="submit-button"> Primary</button>
                    <a href="Javascript:;" class="btn btn-primary m-w-120" id="loading-button" style="display:none;"><i class="fa fa-spinner fa-spin" aria-hidden="true"></i> Loading</a>
					</div>
                </div>
			  </form>
			</div>
		   </div>
		 </div>
	</div>
</div>
	<div class="site-content">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Add Information without Ajax</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-6 col-md-offset-3">
                <form class="form-material" method="post" action="<?php echo $base_url; ?>/executablefiles/addvalue2_exec.php">
                  <div class="form-group">
                    <input class="form-control" type="text" placeholder="Placeholder" name="withoutajaxvalue-1">
                  </div>
                  <div class="form-group">
                    <input class="form-control" type="text" name="withoutajaxvalue-2">
                    <label class="floating-label">Floating label</label>
                  </div>
				  <div class="form-group">
                    <textarea id="ajax-value2" name="withoutajaxvalue-3" class="ckeditor" rows="3"  required></textarea>
                </div>
                  <div class="form-group">
                    <select class="form-control" name="withoutajaxvalue-4">
                      <option value="corporate">Corporate</option>
                      <option value="creative">Creative</option>
                      <option value="ecommerce">eCommerce</option>
                      <option value="mobile">Mobile</option>
                      <option value="retail">Retail</option>
                      <option value="technology">Technology</option>
                      <option value="wedding">Wedding</option>
                    </select>
                  </div>
				  <div class="form-group">
                    <button type="submit" class="btn btn-primary m-w-120" > Primary</button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
	 </div>
	
		

    <div class="site-content">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Add Information with File</h3>
          </div>
          <div class="panel-body">
            <div class="row">
			<div class="col-md-12">
			<form class="form-horizontal" action="<?php echo $base_url; ?>/upload_exec.php" method="post" enctype="multipart/form-data">
			    <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-5">Placeholder Input</label>
                    <div class="col-sm-9">
                      <input id="form-control-5" class="form-control" type="text" name="filewithvalue1" placeholder="Placeholder input text">
                    </div>
                </div>
				<div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-11">Single File input</label>
                    <div class="col-sm-9">
					<!--Use Accept Perameters like accept=".xlsx,.xls,image/*,.doc, .docx,.ppt, .pptx,.txt,.pdf" -->
                      <input id="form-control-11" type="file" accept="image/*" name="file">
                      <p class="help-block">
                        <small>Single file can be uploaded to this field. Allowed types: png gif jpg jpeg.</small>
                      </p>
                    </div>
                  </div>
				  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-11">Multiple File input</label>
                    <div class="col-sm-9">
					<!--Use Accept Perameters like accept=".xlsx,.xls,image/*,.doc, .docx,.ppt, .pptx,.txt,.pdf" -->
                      <input id="form-control-11" type="file"  multiple="multiple" name="files[]">
                      <p class="help-block">
                        <small>Unlimited number of files can be uploaded to this field. Allowed types: Any.</small>
                      </p>
                    </div>
                  </div>
			<div class="form-group">
                    <div class="col-md-offset-3 col-sm-9">
                     <button type="submit" class="btn btn-primary m-w-120">Primary</button>
                    </div>
                </div>
			  </form>
			</div>
			</div>
		  </div>
		</div>
	</div>
    <div class="site-content">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Ajax File Upload with progress bar</h3>
          </div>
          <div class="panel-body">
            <div class="row">
			<div class="col-md-12">
			<div class="alert alert-outline-success alert-dismissable" role="alert" id="success-alert2" style="display:none">
                  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">
                      <i class="zmdi zmdi-close"></i>
                    </span>
                  </button>
                  <span class="alert-icon">
                    <i class="zmdi zmdi-check"></i>
                  </span>
                  <strong>Well done!</strong> You successfully read this important alert message.
                </div>
			<form action="<?php echo $base_url; ?>/upload_back.php" method="post" enctype="multipart/form-data" id="ajaxfileuploadform">
			    
				<div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-11">Single File input</label>
                    <div class="col-sm-9">
					<!--Use Accept Perameters like accept=".xlsx,.xls,image/*,.doc, .docx,.ppt, .pptx,.txt,.pdf" -->
                      <input type="file" accept="image/*" name="file1" id="file1">
                      <p class="help-block">
                        <small>Single file can be uploaded to this field. Allowed types: png gif jpg jpeg.</small>
                      </p>
                    </div>
                  </div>
				  
			<div class="form-group">
                    <div class="col-md-offset-3 col-sm-9">
					<!--Use the Onclick Method only if this form's javascript conflict with any other javascript-->
                     <button type="submit" class="btn btn-primary m-w-120" onclick="myFunction()">Primary</button>
                    </div>
                </div>
			  </form>
			  
			  <!--Progress Bar-->
			  <div class="col-md-6">
                <h5>Progress Status</h5>
                <div class="progress progress-sm">
                  <div class="progress-bar progress-bar-striped active" role="progressbar" aria-valuenow="45" aria-valuemin="0" aria-valuemax="100" style="width: 0%" id="progress">
                    <span class="sr-only">45% Complete</span>
                  </div>
                </div>
              </div>
				
				<!-- -->
			  
			</div>
			</div>
		  </div>
		</div>
	</div>
    <div class="site-content">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Add Location</h3>
          </div>
          <div class="panel-body">
            <div class="row">
			<div class="col-md-12">
			<form class="form-horizontal" method="post" action="<?php echo $base_url; ?>/executablefiles/location_exec.php">
			    <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-5">Add Location with Bing API (Works in both HTTP and HTTPS)</label>
                    <div class="col-sm-9">
                      <input id="searchBox" class="form-control" type="text" placeholder="Placeholder input text" name="bingmap">
                    </div>
                </div>
				<div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-5">Add Location with Google API (Works Only in HTTPS)</label>
                    <div class="col-sm-9">
                      <input id="txtPlaces" class="form-control" type="text" placeholder="Placeholder input text" name="googlemap">
                    </div>
                </div>

			<div class="form-group">
                    <div class="col-md-offset-3 col-sm-9">
                     <button type="submit" class="btn btn-primary m-w-120">Primary</button>
                    </div>
                </div>
			  </form>
			</div>
			</div>
		  </div>
		</div>
	</div>

      <div class="site-content">
        <div class="panel panel-default m-b-0">
          <div class="panel-heading">
            <h3 class="m-y-0">Multiple Uploader with Dropzone without storing data in database</h3>
          </div>
          <div class="panel-body">
            <form action="<?php echo $base_url; ?>/upload.php" class="dropzone">
              <div class="dz-message" data-dz-message>
                <div class="dz-icon">
                  <i class="zmdi zmdi-upload"></i>
                </div>
                <h2>Drop files here or click to upload</h2>
                <span class="text-muted">(This is just a demo dropzone. Selected files are not actually uploaded.)</span>
              </div>
            </form>
          </div>
        </div>
      </div>
      <div class="site-content">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Basic form elements</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-8">
                <form class="form-horizontal">
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-1">Text input</label>
                    <div class="col-sm-9">
                      <input id="form-control-1" class="form-control" type="text">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-2">Rounded text input</label>
                    <div class="col-sm-9">
                      <input id="form-control-2" class="form-control input-pill" type="text">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-3">Thick text input</label>
                    <div class="col-sm-9">
                      <input id="form-control-3" class="form-control b-a-2" type="text">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-4">Password input</label>
                    <div class="col-sm-9">
                      <input id="form-control-4" class="form-control" type="password" value="password">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-5">Placeholder Input</label>
                    <div class="col-sm-9">
                      <input id="form-control-5" class="form-control" type="email" placeholder="Placeholder input text">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-6">Disabled Input</label>
                    <div class="col-sm-9">
                      <input id="form-control-6" class="form-control" type="text" placeholder="Disabled input text" disabled="disabled">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-7">Read only input</label>
                    <div class="col-sm-9">
                      <input id="form-control-7" class="form-control" type="email" value="Read only input text" readonly="readonly">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Static input</label>
                    <div class="col-sm-9">
                      <p class="form-control-static">email@example.com</p>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-8">Textarea</label>
                    <div class="col-sm-9">
                      <textarea id="form-control-8" class="form-control" rows="3"></textarea>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-9">Select</label>
                    <div class="col-sm-9">
                      <select id="form-control-9" class="form-control">
                        <option value="corporate">Corporate</option>
                        <option value="creative">Creative</option>
                        <option value="ecommerce">eCommerce</option>
                        <option value="mobile">Mobile</option>
                        <option value="retail">Retail</option>
                        <option value="technology">Technology</option>
                        <option value="wedding">Wedding</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-10">Multiple select</label>
                    <div class="col-sm-9">
                      <select id="form-control-10" class="form-control" multiple="multiple">
                        <option value="c-plus-plus">C++</option>
                        <option value="css">CSS</option>
                        <option value="java">Java</option>
                        <option value="javascript">JavaScript</option>
                        <option value="php">PHP</option>
                        <option value="python">Python</option>
                        <option value="ruby">Ruby</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-11">File input</label>
                    <div class="col-sm-9">
                      <input id="form-control-11" type="file" accept="image/*" multiple="multiple">
                      <p class="help-block">
                        <small>Unlimited number of files can be uploaded to this field. Allowed types: png gif jpg jpeg.</small>
                      </p>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Checkboxes and radios</label>
                    <div class="col-sm-9">
                      <div class="checkbox">
                        <label>
                          <input type="checkbox" name="signed" checked="checked"> Keep me signed in
                        </label>
                      </div>
                      <div class="radio">
                        <label>
                          <input type="radio" name="period" value="day"> Day
                        </label>
                      </div>
                      <div class="radio">
                        <label>
                          <input type="radio" name="period" value="week" checked="checked"> Week
                        </label>
                      </div>
                      <div class="radio">
                        <label>
                          <input type="radio" name="period" value="month"> Month
                        </label>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Custom form elements</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-8">
                <form class="form-horizontal">
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-21">Custom select</label>
                    <div class="col-sm-9">
                      <select id="form-control-21" class="custom-select">
                        <option value="" selected="selected">Day of the week</option>
                        <option value="1">Monday</option>
                        <option value="2">Tuesday</option>
                        <option value="3">Wednesday</option>
                        <option value="4">Thursday</option>
                        <option value="5">Friday</option>
                        <option value="6">Saturday</option>
                        <option value="7">Sunday</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-22">Custom file inputs</label>
                    <div class="col-sm-9">
                      <label class="btn btn-default file-upload-btn">
                        Choose file...
                        <input id="form-control-22" class="file-upload-input" type="file" name="files[]" multiple="multiple">
                      </label>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                      <div class="input-group">
                        <input class="form-control" type="text" placeholder="Choose file...">
                        <span class="input-group-btn">
                          <label class="btn btn-primary file-upload-btn">
                            <input class="file-upload-input" type="file" name="file">
                            <i class="zmdi zmdi-attachment-alt"></i>
                          </label>
                        </span>
                      </div>
                      <p class="help-block">
                        <small>Click the button next to the input field.</small>
                      </p>
                    </div>
                  </div>
                  <div class="form-group m-b-20">
                    <label class="col-sm-3 control-label">Custom checkboxes</label>
                    <div class="col-sm-9">
                      <div class="custom-controls-stacked">
                        <label class="custom-control custom-control-default custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Default</span>
                        </label>
                        <label class="custom-control custom-control-primary custom-checkbox active">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Primary</span>
                        </label>
                        <label class="custom-control custom-control-success custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Success</span>
                        </label>
                        <label class="custom-control custom-control-info custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Info</span>
                        </label>
                        <label class="custom-control custom-control-warning custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Warning</span>
                        </label>
                        <label class="custom-control custom-control-danger custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Danger</span>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group m-b-20">
                    <label class="col-sm-3 control-label">Custom checkboxes validation states</label>
                    <div class="col-sm-9">
                      <div class="custom-controls-stacked">
                        <label class="custom-control custom-control-success custom-checkbox has-success">
                          <input class="custom-control-input" type="checkbox" name="validation">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">With success</span>
                        </label>
                        <label class="custom-control custom-control-warning custom-checkbox has-warning">
                          <input class="custom-control-input" type="checkbox" name="validation">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">With warning</span>
                        </label>
                        <label class="custom-control custom-control-danger custom-checkbox has-error">
                          <input class="custom-control-input" type="checkbox" name="validation">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">With error</span>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group m-b-20">
                    <label class="col-sm-3 control-label">Button checkboxes</label>
                    <div class="col-sm-9">
                      <div class="btn-group" data-toggle="buttons">
                        <label class="btn btn-default">
                          <input type="checkbox" name="buttonCheckboxes" autocomplete="off"> PHP
                        </label>
                        <label class="btn btn-default">
                          <input type="checkbox" name="buttonCheckboxes" autocomplete="off"> Ruby
                        </label>
                        <label class="btn btn-default">
                          <input type="checkbox" name="buttonCheckboxes" autocomplete="off"> Python
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group m-b-20">
                    <label class="col-sm-3 control-label">Switches</label>
                    <div class="col-sm-9">
                      <div class="switches-stacked">
                        <label class="switch">
                          <input type="checkbox" name="switches" class="s-input">
                          <span class="s-content">
                            <span class="s-track"></span>
                            <span class="s-handle"></span>
                          </span>
                        </label>
                        <label class="switch switch-primary">
                          <input type="checkbox" name="switches" class="s-input" checked="checked">
                          <span class="s-content">
                            <span class="s-track"></span>
                            <span class="s-handle"></span>
                          </span>
                        </label>
                        <label class="switch switch-success">
                          <input type="checkbox" name="switches" class="s-input" checked="checked">
                          <span class="s-content">
                            <span class="s-track"></span>
                            <span class="s-handle"></span>
                          </span>
                        </label>
                        <label class="switch switch-info">
                          <input type="checkbox" name="switches" class="s-input" checked="checked">
                          <span class="s-content">
                            <span class="s-track"></span>
                            <span class="s-handle"></span>
                          </span>
                        </label>
                        <label class="switch switch-warning">
                          <input type="checkbox" name="switches" class="s-input" checked="checked">
                          <span class="s-content">
                            <span class="s-track"></span>
                            <span class="s-handle"></span>
                          </span>
                        </label>
                        <label class="switch switch-danger">
                          <input type="checkbox" name="switches" class="s-input" checked="checked">
                          <span class="s-content">
                            <span class="s-track"></span>
                            <span class="s-handle"></span>
                          </span>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Custom radios</label>
                    <div class="col-sm-9">
                      <div class="custom-controls-stacked">
                        <label class="custom-control custom-control-primary custom-radio">
                          <input class="custom-control-input" type="radio" name="period" value="day">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Day</span>
                        </label>
                        <label class="custom-control custom-control-primary custom-radio">
                          <input class="custom-control-input" type="radio" name="period" value="week" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Week</span>
                        </label>
                        <label class="custom-control custom-control-primary custom-radio">
                          <input class="custom-control-input" type="radio" name="period" value="month">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Month</span>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group m-b-20">
                    <label class="col-sm-3 control-label">Button radios</label>
                    <div class="col-sm-9">
                      <div class="btn-group" data-toggle="buttons">
                        <label class="btn btn-outline-primary active">
                          <input type="radio" name="buttonRadios" id="buttonRadios1" autocomplete="off" checked="checked"> PHP
                        </label>
                        <label class="btn btn-outline-primary">
                          <input type="radio" name="buttonRadios" id="buttonRadios2" autocomplete="off"> Ruby
                        </label>
                        <label class="btn btn-outline-primary">
                          <input type="radio" name="buttonRadios" id="buttonRadios3" autocomplete="off"> Python
                        </label>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Input sizing</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-8">
                <form class="form-horizontal">
                  <div class="form-group form-group-lg">
                    <label class="col-sm-3 control-label" for="form-control-12">Large label</label>
                    <div class="col-sm-9">
                      <input id="form-control-12" class="form-control" type="text" placeholder="Large input">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-13">Default label</label>
                    <div class="col-sm-9">
                      <input id="form-control-13" class="form-control" type="text" placeholder="Default input">
                    </div>
                  </div>
                  <div class="form-group form-group-sm">
                    <label class="col-sm-3 control-label" for="form-control-14">Small label</label>
                    <div class="col-sm-9">
                      <input id="form-control-14" class="form-control" type="text" placeholder="Small input">
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Validation states</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-8">
                <form class="form-horizontal">
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-15">Success input</label>
                    <div class="col-sm-9 has-success has-feedback">
                      <input id="form-control-15" class="form-control" type="text">
                      <span class="form-control-feedback" aria-hidden="true">
                        <i class="zmdi zmdi-check"></i>
                      </span>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-16">Warning input</label>
                    <div class="col-sm-9 has-warning has-feedback">
                      <input id="form-control-16" class="form-control" type="text">
                      <span class="form-control-feedback" aria-hidden="true">
                        <i class="zmdi zmdi-alert-triangle"></i>
                      </span>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-17">Error input</label>
                    <div class="col-sm-9 has-error has-feedback">
                      <input id="form-control-17" class="form-control" type="text">
                      <span class="form-control-feedback" aria-hidden="true">
                        <i class="zmdi zmdi-close"></i>
                      </span>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-18">Input with help text</label>
                    <div class="col-sm-9 has-error has-feedback">
                      <input id="form-control-18" class="form-control" type="email" value="email@example.com">
                      <span class="form-control-feedback" aria-hidden="true">
                        <i class="zmdi zmdi-close"></i>
                      </span>
                      <p class="help-block">Please enter a valid email address</p>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-19">Checkbox</label>
                    <div class="col-sm-9">
                      <div class="has-success">
                        <div class="checkbox">
                          <label>
                            <input type="checkbox" id="checkboxSuccess" value="option1"> Checkbox with success
                          </label>
                        </div>
                      </div>
                      <div class="has-warning">
                        <div class="checkbox">
                          <label>
                            <input type="checkbox" id="checkboxWarning" value="option1"> Checkbox with warning
                          </label>
                        </div>
                      </div>
                      <div class="has-error">
                        <div class="checkbox">
                          <label>
                            <input type="checkbox" id="checkboxError" value="option1"> Checkbox with error
                          </label>
                        </div>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class="panel panel-default m-b-0">
          <div class="panel-heading">
            <h3 class="m-y-0">Input groups</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-8">
                <form class="form-horizontal">
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-20">Input addons</label>
                    <div class="col-sm-9">
                      <div class="input-group">
                        <input id="form-control-20" class="form-control" type="text" placeholder="Domain name">
                        <span class="input-group-addon">.com</span>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                      <div class="input-group">
                        <span class="input-group-addon">
                          <i class="zmdi zmdi-account"></i>
                        </span>
                        <input class="form-control" type="text" placeholder="Username">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                      <div class="input-group">
                        <span class="input-group-addon">
                          <i class="zmdi zmdi-lock"></i>
                        </span>
                        <input class="form-control" type="password" placeholder="Password">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Button addons</label>
                    <div class="col-sm-9">
                      <div class="input-group">
                        <input type="text" class="form-control" placeholder="Search for...">
                        <span class="input-group-btn">
                          <button class="btn btn-default" type="button">
                            <i class="zmdi zmdi-search"></i>
                          </button>
                        </span>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                      <div class="input-group">
                        <div class="input-group-btn">
                          <button type="button" class="btn btn-default dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Action
                            <span class="caret"></span>
                          </button>
                          <ul class="dropdown-menu">
                            <li><a href="#">Action</a></li>
                            <li><a href="#">Another action</a></li>
                            <li><a href="#">Something else here</a></li>
                            <li role="separator" class="divider"></li>
                            <li><a href="#">Separated link</a></li>
                          </ul>
                        </div>
                        <input class="form-control" type="text" value="New project title">
                        <span class="input-group-btn">
                          <button class="btn btn-primary" type="button">Create!</button>
                        </span>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
	  
	  <div class="site-content">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Vertical form</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-sm-6 col-sm-offset-3 col-md-4 col-md-offset-4">
                <form>
                  <div class="form-group">
                    <label for="form-control-1">Email address</label>
                    <input type="email" class="form-control" id="form-control-1" placeholder="Email">
                  </div>
                  <div class="form-group">
                    <label for="form-control-2">Password</label>
                    <input type="password" class="form-control" id="form-control-2" placeholder="Password">
                  </div>
                  <div class="form-group">
                    <label class="custom-control custom-control-primary custom-checkbox active">
                      <input class="custom-control-input" type="checkbox" name="mode" checked="checked">
                      <span class="custom-control-indicator"></span>
                      <span class="custom-control-label">Keep me signed in</span>
                    </label>
                    <a href="#" class="pull-right">Forgot password?</a>
                  </div>
                  <button type="submit" class="btn btn-primary btn-block">Submit</button>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Horizontal form</h3>
          </div>
          <div class="panel-body">
            <form class="form-horizontal">
              <div class="form-group">
                <label for="form-control-3" class="col-sm-3 col-md-4 control-label">Email</label>
                <div class="col-sm-6 col-md-4">
                  <input type="email" class="form-control" id="form-control-3" placeholder="Email">
                </div>
              </div>
              <div class="form-group">
                <label for="form-control-4" class="col-sm-3 col-md-4 control-label">Password</label>
                <div class="col-sm-6 col-md-4">
                  <input type="password" class="form-control" id="form-control-4" placeholder="Password">
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-offset-3 col-sm-6 col-md-offset-4 col-md-4">
                  <label class="custom-control custom-control-primary custom-checkbox active">
                    <input class="custom-control-input" type="checkbox" name="mode" checked="checked">
                    <span class="custom-control-indicator"></span>
                    <span class="custom-control-label">Keep me signed in</span>
                  </label>
                </div>
              </div>
              <div class="form-group">
                <div class="col-sm-offset-3 col-sm-6 col-md-offset-4 col-md-4">
                  <button type="submit" class="btn btn-primary">Sign in</button>
                </div>
              </div>
            </form>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Inline form</h3>
          </div>
          <div class="panel-body">
            <div class="text-center">
              <form class="form-inline">
                <div class="form-group">
                  <div class="input-group">
                    <span class="input-group-addon">
                      <i class="zmdi zmdi-account"></i>
                    </span>
                    <input class="form-control" type="text" placeholder="Jane Doe">
                  </div>
                </div>
                <div class="form-group">
                  <div class="input-group">
                    <span class="input-group-addon">
                      <i class="zmdi zmdi-email"></i>
                    </span>
                    <input class="form-control" type="email" placeholder="jane.doe@example.com">
                  </div>
                </div>
                <button type="submit" class="btn btn-primary">Send invitation</button>
              </form>
            </div>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Column sizing</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-sm-12">
                <div class="row m-b-15">
                  <div class="col-xs-2">
                    <input class="form-control" type="text" placeholder="col-xs-2">
                  </div>
                  <div class="col-xs-2">
                    <input class="form-control" type="text" placeholder="col-xs-2">
                  </div>
                  <div class="col-xs-2">
                    <input class="form-control" type="text" placeholder="col-xs-2">
                  </div>
                  <div class="col-xs-2">
                    <input class="form-control" type="text" placeholder="col-xs-2">
                  </div>
                  <div class="col-xs-2">
                    <input class="form-control" type="text" placeholder="col-xs-2">
                  </div>
                  <div class="col-xs-2">
                    <input class="form-control" type="text" placeholder="col-xs-2">
                  </div>
                </div>
                <div class="row m-b-15">
                  <div class="col-xs-3">
                    <input class="form-control" type="text" placeholder="col-xs-3">
                  </div>
                  <div class="col-xs-3">
                    <input class="form-control" type="text" placeholder="col-xs-3">
                  </div>
                  <div class="col-xs-3">
                    <input class="form-control" type="text" placeholder="col-xs-3">
                  </div>
                  <div class="col-xs-3">
                    <input class="form-control" type="text" placeholder="col-xs-3">
                  </div>
                </div>
                <div class="row m-b-15">
                  <div class="col-xs-4">
                    <input class="form-control" type="text" placeholder="col-xs-4">
                  </div>
                  <div class="col-xs-4">
                    <input class="form-control" type="text" placeholder="col-xs-4">
                  </div>
                  <div class="col-xs-4">
                    <input class="form-control" type="text" placeholder="col-xs-4">
                  </div>
                </div>
                <div class="row m-b-15">
                  <div class="col-xs-6">
                    <input class="form-control" type="text" placeholder="col-xs-6">
                  </div>
                  <div class="col-xs-6">
                    <input class="form-control" type="text" placeholder="col-xs-6">
                  </div>
                </div>
                <div class="row">
                  <div class="col-xs-12">
                    <input class="form-control" type="text" placeholder="col-xs-12">
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
	        <div class="site-content">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Form masks</h3>
          </div>
          <div class="panel-body">
            <form id="inputmasks" class="form-horizontal">
              <div class="form-group row gutter-xs">
                <label class="col-md-3 control-label" for="form-control-1">Date</label>
                <div class="col-md-6">
                  <input id="form-control-1" class="form-control" type="text" data-inputmask="'alias': 'dd-mm-yyyy'">
                  <p class="text-muted help-block">dd-mm-yyyy</p>
                </div>
              </div>
              <div class="form-group row gutter-xs">
                <label class="col-md-3 control-label" for="form-control-2">Time</label>
                <div class="col-md-6">
                  <input id="form-control-2" class="form-control" type="text" data-inputmask="'alias': 'hh:mm'">
                  <p class="text-muted help-block">hh:mm</p>
                </div>
              </div>
              <div class="form-group row gutter-xs">
                <label class="col-md-3 control-label" for="form-control-3">Phone</label>
                <div class="col-md-6">
                  <input id="form-control-3" class="form-control" type="text" data-inputmask="'alias': '(999) 999-9999'">
                  <p class="text-muted help-block">(___) ___-____</p>
                </div>
              </div>
              <div class="form-group row gutter-xs">
                <label class="col-md-3 control-label" for="form-control-4">License plate</label>
                <div class="col-md-6">
                  <input id="form-control-4" class="form-control" type="text" data-inputmask="'alias': '[9-]AAA-999'">
                  <p class="text-muted help-block">[9-]AAA-999</p>
                </div>
              </div>
              <div class="form-group row gutter-xs">
                <label class="col-md-3 control-label" for="form-control-5">Currency</label>
                <div class="col-md-6">
                  <input id="form-control-5" class="form-control" type="text" data-inputmask="'alias': 'numeric', 'groupSeparator': ',', 'autoGroup': true, 'digits': 2, 'digitsOptional': false, 'prefix': '$ ', 'placeholder': '0'">
                  <p class="text-muted help-block">$ 0.00</p>
                </div>
              </div>
              <div class="form-group row gutter-xs">
                <label class="col-md-3 control-label" for="form-control-6">Decimal</label>
                <div class="col-md-6">
                  <input id="form-control-6" class="form-control" type="text" data-inputmask="'alias': 'decimal', 'groupSeparator': ',', 'autoGroup': true">
                  <p class="text-muted help-block">Decimal value</p>
                </div>
              </div>
              <div class="form-group row gutter-xs">
                <label class="col-md-3 control-label" for="form-control-7">URL</label>
                <div class="col-md-6">
                  <input id="form-control-7" class="form-control" type="text" data-inputmask="'alias': 'url'">
                  <p class="text-muted help-block">http://...</p>
                </div>
              </div>
              <div class="form-group row gutter-xs">
                <label class="col-md-3 control-label" for="form-control-8">IP address</label>
                <div class="col-md-6">
                  <input id="form-control-8" class="form-control" type="text" data-inputmask="'alias': 'ip'">
                  <p class="text-muted help-block">___.___.___.___</p>
                </div>
              </div>
              <div class="form-group row gutter-xs">
                <label class="col-md-3 control-label" for="form-control-9">Email</label>
                <div class="col-md-6">
                  <input id="form-control-9" class="form-control" type="text" data-inputmask="'alias': 'email'">
                  <p class="text-muted help-block">_@_._</p>
                </div>
              </div>
            </form>
          </div>
        </div>
      </div>
	        <div class="site-content">
        <div class="panel panel-default m-b-0">
          <div class="form-wizard">
            <div class="fw-header">
              <ul class="nav nav-pills">
                <li class="active"><a href="#tab1" data-toggle="tab">Step 1 <span class="chevron"></span></a></li>
                <li><a href="#tab2" data-toggle="tab">Step 2 <span class="chevron"></span></a></li>
                <li><a href="#tab3" data-toggle="tab">Step 3 <span class="chevron"></span></a></li>
              </ul>
            </div>
            <div class="tab-content p-x-15">
              <div class="tab-pane active" id="tab1">
                <h3 class="m-t-0 m-b-30">Basic information</h3>
                <form class="form-horizontal">
                  <div class="form-group">
                    <label for="form-control-1" class="col-sm-3 control-label">Username</label>
                    <div class="col-sm-6">
                      <div class="input-group">
                        <span class="input-group-addon">@</span>
                        <input type="text" class="form-control" id="form-control-1" placeholder="Username">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="form-control-2" class="col-sm-3 control-label">Email</label>
                    <div class="col-sm-6">
                      <input type="email" class="form-control" id="form-control-2" placeholder="Email">
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="form-control-3" class="col-sm-3 control-label">Choose counrty</label>
                    <div class="col-sm-6">
                      <select id="form-control-3" class="custom-select">
                        <option value="" selected="selected">Choose counrty</option>
                        <option value="1">Denmark</option>
                        <option value="2">Iceland</option>
                        <option value="3">Republic of Macedonia</option>
                        <option value="4">Saint Kitts and Nevis</option>
                        <option value="5">Vanuatu</option>
                        <option value="6">Yemen</option>
                        <option value="7">Zimbabwe</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="form-control-4" class="col-sm-3 control-label">Password</label>
                    <div class="col-sm-6">
                      <input type="password" class="form-control" id="form-control-4" placeholder="Password">
                    </div>
                  </div>
                </form>
              </div>
              <div class="tab-pane" id="tab2">
                <h3 class="m-t-0 m-b-30">Payment details</h3>
                <form class="form-horizontal">
                  <div class="form-group">
                    <label for="form-control-5" class="col-sm-3 control-label">Choose counrty</label>
                    <div class="col-sm-6">
                      <select id="form-control-5" class="custom-select">
                        <option value="" selected="selected">Choose counrty</option>
                        <option value="1">Denmark</option>
                        <option value="2">Iceland</option>
                        <option value="3">Republic of Macedonia</option>
                        <option value="4">Saint Kitts and Nevis</option>
                        <option value="5">Vanuatu</option>
                        <option value="6">Yemen</option>
                        <option value="7">Zimbabwe</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="form-control-6" class="col-sm-3 control-label">Card number</label>
                    <div class="col-sm-6">
                      <input type="text" class="form-control" id="form-control-6" placeholder="Card number">
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-6 col-sm-offset-3">
                      <div class="row gutter-sm">
                        <div class="col-sm-6 m-b-15 m-sm-b-0">
                          <input type="email" class="form-control" placeholder="CVC/CVV">
                        </div>
                        <div class="col-sm-3 m-b-15 m-sm-b-0">
                          <input type="text" class="form-control" placeholder="MM">
                        </div>
                        <div class="col-sm-3 m-b-15 m-sm-b-0">
                          <input type="text" class="form-control" placeholder="YY">
                        </div>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label for="form-control-7" class="col-sm-3 control-label">Type</label>
                    <div class="col-sm-6">
                      <div class="btn-group" data-toggle="buttons">
                        <label class="btn btn-outline-primary active">
                          <input type="radio" name="buttonRadios" id="buttonRadios1" autocomplete="off" checked="checked"> Visa
                        </label>
                        <label class="btn btn-outline-primary">
                          <input type="radio" name="buttonRadios" id="buttonRadios2" autocomplete="off"> MasterCard
                        </label>
                        <label class="btn btn-outline-primary">
                          <input type="radio" name="buttonRadios" id="buttonRadios3" autocomplete="off"> Maestro
                        </label>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
              <div class="tab-pane" id="tab3">
                <h3 class="m-t-0 m-b-30">Settings</h3>
                <form class="form-horizontal">
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-8">Avatar</label>
                    <div class="col-sm-6">
                      <label class="btn btn-default file-upload-btn">
                        Choose file...
                        <input id="form-control-8" class="file-upload-input" type="file" name="files[]" multiple="multiple">
                      </label>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-9">Checkout day</label>
                    <div class="col-sm-6">
                      <select id="form-control-9" class="custom-select">
                        <option value="" selected="selected">Select checkout day</option>
                        <option value="1">Monday</option>
                        <option value="2">Tuesday</option>
                        <option value="3">Wednesday</option>
                        <option value="4">Thursday</option>
                        <option value="5">Friday</option>
                        <option value="6">Saturday</option>
                        <option value="7">Sunday</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Notifications</label>
                    <div class="col-sm-9">
                      <div class="custom-controls-stacked">
                        <label class="custom-control custom-control-primary custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Rating reminders</span>
                        </label>
                        <label class="custom-control custom-control-primary custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Expiring support</span>
                        </label>
                        <label class="custom-control custom-control-primary custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Daily summary emails</span>
                        </label>
                        <label class="custom-control custom-control-primary custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Team comment notifications</span>
                        </label>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
            <div class="fw-footer">
              <ul class="pager wizard">
                <li class="previous first" style="display:none"><a href="javascript:;">First</a></li>
                <li class="previous"><a href="javascript:;">Previous</a></li>
                <li class="next last" style="display:none"><a href="javascript:;">Last</a></li>
                <li class="next"><a href="javascript:;">Next</a></li>
              </ul>
            </div>
            <div id="bar" class="progress">
              <div class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%"></div>
            </div>
          </div>
        </div>
      </div>
	        <div class="site-content">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Material form elements</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-6 col-md-offset-3">
                <form class="form-material">
                  <div class="form-group">
                    <input class="form-control" type="text" placeholder="Placeholder">
                  </div>
                  <div class="form-group">
                    <input class="form-control" type="text">
                    <label class="floating-label">Floating label</label>
                  </div>
                  <div class="form-group">
                    <input class="form-control" type="text" disabled="disabled">
                    <label class="floating-label">Disabled</label>
                  </div>
                  <div class="form-group">
                    <select class="form-control">
                      <option value="corporate">Corporate</option>
                      <option value="creative">Creative</option>
                      <option value="ecommerce">eCommerce</option>
                      <option value="mobile">Mobile</option>
                      <option value="retail">Retail</option>
                      <option value="technology">Technology</option>
                      <option value="wedding">Wedding</option>
                    </select>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Input sizing</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-6 col-md-offset-3">
                <form class="form-material">
                  <div class="form-group form-group-lg">
                    <input class="form-control" type="text">
                    <label class="floating-label">Large input</label>
                  </div>
                  <div class="form-group">
                    <input class="form-control" type="text">
                    <label class="floating-label">Default input</label>
                  </div>
                  <div class="form-group form-group-sm">
                    <input class="form-control" type="text">
                    <label class="floating-label">Small input</label>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Validation states</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-6 col-md-offset-3">
                <form class="form-material">
                  <div class="form-group has-success">
                    <input class="form-control" type="password" value="password">
                    <label class="floating-label">Success</label>
                  </div>
                  <div class="form-group has-warning">
                    <input class="form-control" type="password" value="password">
                    <label class="floating-label">Warning</label>
                  </div>
                  <div class="form-group has-error">
                    <input class="form-control" type="password" value="password">
                    <label class="floating-label">Error</label>
                    <p class="help-block">Please enter a valid email address</p>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
	        <div class="site-content">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Select2</h3>
          </div>
          <div class="panel-body">
            <form class="form-horizontal">
              <div class="form-group">
                <label for="form-control-1" class="col-sm-3 col-md-4 control-label">Single select box</label>
                <div class="col-sm-6 col-md-4">
                  <select id="form-control-1" class="form-control" data-plugin="select2" data-options="{ theme: bootstrap }">
                    <option value="option1">HTML</option>
                    <option value="option2">CSS</option>
                    <option value="option3">Javascript</option>
                    <option value="option4">PHP</option>
                    <option value="option5">Bootstrap</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label for="form-control-1" class="col-sm-3 col-md-4 control-label">Multiple select box</label>
                <div class="col-sm-6 col-md-4">
                  <select id="form-control-2" class="form-control" data-plugin="select2" multiple="multiple">
                    <option value="option1">HTML</option>
                    <option value="option2">CSS</option>
                    <option value="option3">Javascript</option>
                    <option value="option4">PHP</option>
                    <option value="option5">Bootstrap</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label for="form-control-3" class="col-sm-3 col-md-4 control-label">Limiting number of selections</label>
                <div class="col-sm-6 col-md-4">
                  <select id="form-control-3" class="form-control" data-plugin="select2" multiple="multiple" data-options="{ maximumSelectionLength: 3 }">
                    <option value="option1">HTML</option>
                    <option value="option2">CSS</option>
                    <option value="option3">Javascript</option>
                    <option value="option4">PHP</option>
                    <option value="option5">Bootstrap</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label for="form-control-4" class="col-sm-3 col-md-4 control-label">Tagging support</label>
                <div class="col-sm-6 col-md-4">
                  <select id="form-control-4" class="form-control" data-plugin="select2" multiple="multiple" data-options="{ tags: true }">
                    <option value="option1">HTML</option>
                    <option value="option2">CSS</option>
                    <option value="option3">Javascript</option>
                    <option value="option4">PHP</option>
                    <option value="option5">Bootstrap</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label for="form-control-5" class="col-sm-3 col-md-4 control-label">Automatic tokenization</label>
                <div class="col-sm-6 col-md-4">
                  <select id="form-control-5" class="form-control" data-plugin="select2" multiple="multiple" data-options="{ tags: true, tokenSeparators: [',', ' '] }">
                    <option value="option1">HTML</option>
                    <option value="option2">CSS</option>
                    <option value="option3">Javascript</option>
                    <option value="option4">PHP</option>
                    <option value="option5">Bootstrap</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label for="form-control-6" class="col-sm-3 col-md-4 control-label">Placeholders</label>
                <div class="col-sm-6 col-md-4">
                  <select id="form-control-6" class="form-control" data-plugin="select2" data-options="{ placeholder: 'Select a state', allowClear: true }">
                    <option value="option1">HTML</option>
                    <option value="option2">CSS</option>
                    <option value="option3">Javascript</option>
                    <option value="option4">PHP</option>
                    <option value="option5">Bootstrap</option>
                  </select>
                </div>
              </div>
            </form>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Switchery</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-4">
                <p class="text-muted m-b-15">Change color with <code>data-color</code>.</p>
                <div class="pull-left m-r-15">
                  <input type="checkbox" class="js-switch" data-size="small" data-color="#1d87e4" checked="checked">
                </div>
                <div class="pull-left m-r-15">
                  <input type="checkbox" class="js-switch" data-size="small" data-color="#34a853" checked="checked">
                </div>
                <div class="pull-left">
                  <input type="checkbox" class="js-switch" data-size="small" data-color="#7d57c1" checked="checked">
                </div>
              </div>
              <div class="col-md-4">
                <p class="text-muted m-b-15">Change secondary color with <code>data-secondary-color</code>.</p>
                <div class="pull-left m-r-15">
                  <input type="checkbox" class="js-switch" data-size="small" data-color="#ddd" data-secondary-color="#faa800">
                </div>
                <div class="pull-left m-r-15">
                  <input type="checkbox" class="js-switch" data-size="small" data-color="#ddd" data-secondary-color="#e53935">
                </div>
                <div class="pull-lef">
                  <input type="checkbox" class="js-switch" data-size="small" data-color="#ddd" data-secondary-color="#1d87e4">
                </div>
              </div>
              <div class="col-md-4">
                <p class="text-muted m-b-15">Add <code>data-size="small"</code>, <code>data-size="large"</code> to your input element for different sizes.</p>
                <div class="pull-left m-r-15">
                  <input type="checkbox" class="js-switch" data-color="#1d87e4" data-size="small" checked="checked">
                </div>
                <div class="pull-left m-r-15">
                  <input type="checkbox" class="js-switch" data-color="#1d87e4" checked="checked">
                </div>
                <div class="pull-left">
                  <input type="checkbox" class="js-switch" data-color="#1d87e4" data-size="large" checked="checked">
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Sliders</h3>
          </div>
          <div class="panel-body">
            <p class="text-muted m-b-15">Horizontal slider.</p>
            <div class="row">
              <div class="col-sm-4">
                <div class="m-b-30">
                  <input type="text" data-plugin="bootstrapslider" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="10" data-slider-handle="square">
                </div>
              </div>
              <div class="col-sm-4">
                <div class="slider-primary m-b-30">
                  <input type="text" data-plugin="bootstrapslider" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="10" data-slider-handle="square">
                </div>
              </div>
              <div class="col-sm-4">
                <div class="slider-success m-b-30">
                  <input type="text" data-plugin="bootstrapslider" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="10" data-slider-handle="square">
                </div>
              </div>
              <div class="col-sm-4">
                <div class="slider-info m-b-30">
                  <input type="text" data-plugin="bootstrapslider" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="10" data-slider-handle="square">
                </div>
              </div>
              <div class="col-sm-4">
                <div class="slider-warning m-b-30">
                  <input type="text" data-plugin="bootstrapslider" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="10" data-slider-handle="square">
                </div>
              </div>
              <div class="col-sm-4">
                <div class="slider-danger m-b-30">
                  <input type="text" data-plugin="bootstrapslider" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="10" data-slider-handle="square">
                </div>
              </div>
            </div>
            <p class="text-muted m-b-15">Range slider.</p>
            <div class="slider-primary m-b-30">
              <b>€ 10</b>
              <b class="pull-right">€ 1000</b>
              <input type="text" data-plugin="bootstrapslider" data-slider-min="10" data-slider-max="1000" data-slider-step="5" data-slider-value="[250,450]">
            </div>
            <p class="text-muted m-b-15">Vertical slider.</p>
            <div class="pull-left m-r-30">
              <input type="text" data-plugin="bootstrapslider" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="14" data-slider-handle="square" data-slider-selection="after" data-slider-reversed="true" data-slider-orientation="vertical">
            </div>
            <div class="slider-primary pull-left m-r-30">
              <input type="text" data-plugin="bootstrapslider" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="12" data-slider-handle="square" data-slider-selection="after" data-slider-reversed="true" data-slider-orientation="vertical">
            </div>
            <div class="slider-success pull-left m-r-30">
              <input type="text" data-plugin="bootstrapslider" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="10" data-slider-handle="square" data-slider-selection="after" data-slider-reversed="true" data-slider-orientation="vertical">
            </div>
            <div class="slider-info pull-left m-r-30">
              <input type="text" data-plugin="bootstrapslider" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="8" data-slider-handle="square" data-slider-selection="after" data-slider-reversed="true" data-slider-orientation="vertical">
            </div>
            <div class="slider-warning pull-left m-r-30">
              <input type="text" data-plugin="bootstrapslider" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="10" data-slider-handle="square" data-slider-selection="after" data-slider-reversed="true" data-slider-orientation="vertical">
            </div>
            <div class="slider-danger pull-left m-r-30">
              <input type="text" data-plugin="bootstrapslider" data-slider-min="0" data-slider-max="20" data-slider-step="1" data-slider-value="12" data-slider-handle="square" data-slider-selection="after" data-slider-reversed="true" data-slider-orientation="vertical">
            </div>
          </div>
        </div>
        <div class="panel panel-default m-b-0">
          <div class="panel-heading">
            <h3 class="m-y-0">Adjustable textarea</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-sm-6">
                <form>
                  <div class="form-group m-b-0">
                    <textarea data-plugin="autosize" class="form-control" placeholder="Try typing something..." style="resize: none; height: 60px"></textarea>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
	  <div class="site-content">
        <div class="panel panel-default m-b-0">
          <div class="panel-heading">
            <h3 class="m-y-0">Uploader</h3>
          </div>
          <div class="panel-body">
            <form action="http://big-bang-studio.com/file-upload" class="dropzone">
              <div class="dz-message" data-dz-message>
                <div class="dz-icon">
                  <i class="zmdi zmdi-upload"></i>
                </div>
                <h2>Drop files here or click to upload</h2>
                <span class="text-muted">(This is just a demo dropzone. Selected files are not actually uploaded.)</span>
              </div>
            </form>
          </div>
        </div>
      </div>
	  <!---->
	  
<!--Add Footer Web Part Here-->
<?php include('webparts/footer.php'); ?>
<!---->