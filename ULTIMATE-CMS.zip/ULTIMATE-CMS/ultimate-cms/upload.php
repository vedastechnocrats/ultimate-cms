<?php
$target_dir = "dropzoneupload/";
$target_file = $target_dir . basename($_FILES["file"]["name"]);

$temp = explode(".", $_FILES['file']['name']);
$newfilename = round(microtime(true)) . '.' . end($temp);

if (move_uploaded_file($_FILES["file"]["tmp_name"], $target_dir.$newfilename)) {
 $status = 1;
}
?>