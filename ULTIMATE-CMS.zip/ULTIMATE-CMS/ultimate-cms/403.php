<?php require ('webconfig/config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description" content="">
    <title>Ultimate CMS</title>
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.html">
    <link rel="icon" type="image/png" href="<?php echo $base_url; ?>/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="<?php echo $base_url; ?>/favicon-16x16.png" sizes="16x16">
    <link rel="manifest" href="manifest.html">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/vendor.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/cosmos.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/application.min.css">
  </head>
  <body class="error-body">
    <div class="container-fluid">
      <div class="row">
        <div class="col-sm-6 col-sm-offset-3">
          <div class="error">
            <div class="e-icon text-danger">
              <i class="zmdi zmdi-help-outline"></i>
            </div>
            <h1>403</h1>
            <h2>Forbidden error</h2>
            <div class="e-text">Sorry, you don't have permission to access on this server.</div>
            <button type="button" class="btn btn-danger btn-lg">Go to home page</button>
            <div class="e-social">
              <a href="#">
                <i class="zmdi zmdi-github"></i>
              </a>
              <a href="#">
                <i class="zmdi zmdi-twitter"></i>
              </a>
              <a href="#">
                <i class="zmdi zmdi-dribbble"></i>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
    <script src="<?php echo $base_url; ?>/js/vendor.min.js"></script>
    <script src="<?php echo $base_url; ?>/js/cosmos.min.js"></script>
    <script src="<?php echo $base_url; ?>/js/application.min.js"></script>
  </body>

</html>