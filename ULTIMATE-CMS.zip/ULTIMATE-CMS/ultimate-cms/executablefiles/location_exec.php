<?php

require('../webconfig/config.php');

//Check Either We are getting value using post method or not
if($_POST)
 {
	 //Get all the value using POST Method
	 $withoutajaxvalue_1=$_POST['bingmap'];
	 $withoutajaxvalue_2=$_POST['googlemap'];
     //
	 
	 
	 //Exeception Handling Try the SQl to execute if it is correct everything inside try will happen
	 try {
	 //Prepare the SQL Statement
	 $stmt = $db_con->prepare("INSERT INTO `location_tb`(`field1`, `field2`) VALUES
	 (:withoutajaxvalue_1,:withoutajaxvalue_2)");
	   
	 //Bind all the variables into parameter to store the data
	   $stmt->bindParam(":withoutajaxvalue_1",$withoutajaxvalue_1);
	   $stmt->bindParam(":withoutajaxvalue_2",$withoutajaxvalue_2);

	   
   
     //Execute and check execution success or not
		if($stmt->execute())
		{
			//Execution Success do something 
			//Redirect the page where the value is submitted with a variable status and set the value success
			header("location: $base_url/addvalue/?status=success");
			
		}else{
			//Execution Failed do something 
			//Redirect the page where the value is submitted with a variable status and set the value failed
			header("location: $base_url/addvalue/?status=failed");
		}
	 }
	 //SQl Or Database Configuration is not correct
	 //Store the exeception message in a variable
	 catch(PDOException $ex){
		 //Printout the error message
		echo "A problem occured :" .$ex->getMessage(); 
	 }
		
		
 }else{
	 echo "No Value from Post Method";
 }


?>