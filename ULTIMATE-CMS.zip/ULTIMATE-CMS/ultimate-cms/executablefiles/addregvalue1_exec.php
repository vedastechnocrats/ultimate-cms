<?php

require('../webconfig/config.php');

//Check Either We are getting value using post method or not
if($_POST)
 {
	 //Get all the value using POST Method
	 $ajax_value1=$_POST['ajax-value1'];
	 $ajax_value2=$_POST['ajax-value2'];
	 $ajax_value3=$_POST['ajax-value3'];
	 $ajax_value4=$_POST['ajax-value4'];
	 //
	 
	 //Get Todays Date//
	 $joining_date= date('Y-m-d H:i:s');
	 //Date format https://www.w3schools.com/php/func_date_date_format.asp //
	 
	 
	 
	 //Exeception Handling Try the SQl to execute if it is correct everything inside try will happen
	 try {
	 //Prepare the SQL Statement
	 $stmt = $db_con->prepare("INSERT INTO `requestforaccount_tb`(`name`, `email`, `mobile`, `message`,`request_date`) VALUES
	 (:ajax_value1,:ajax_value2,:ajax_value3,:ajax_value4,:ajax_value5)");
	   
	 //Bind all the variables into parameter to store the data
	   $stmt->bindParam(":ajax_value1",$ajax_value1);
	   $stmt->bindParam(":ajax_value2",$ajax_value2);
	   $stmt->bindParam(":ajax_value3",$ajax_value3);
	   $stmt->bindParam(":ajax_value4",$ajax_value4);
	   $stmt->bindParam(":ajax_value5",$joining_date);
	   
   
     //Execute and check execution success or not
		if($stmt->execute())
		{
			//Execution Success do something 
			//Send a Message to User
			
			
			$to = $ajax_value2;
			$subject = "Thank you from Ultimate CMS";

			$message = "
			<html>
			<head>
			<title>Thank you from Ultimate CMS</title>
			</head>
			<body>
			<center><img src=""/></center>
			<br/><br/>
			<h4>Thank you for sending your request to us</h4>
			<p>Hi $ajax_value1</p>
			<p>We are processing your request and will get back to you with your account credentials ASAP</p>
			<p>Thank for choosing us. Ultimate CMS is tool which have all the facility needed to create a CMS.</p>
			<p>Ultimate CMS contains tool and source code to add info with and without ajax. Edit, Delete using ajax and non ajax function.</p>
			<p>It also includes fullcanlenderjs, chartjs, different ui elements with php and mysql.</p>
			<p>Hope it will help you in every aspects for your web development journey</p>
			<p>Thanks and Regards</p>
			<p>Ultimate CMS Team</p>
			<p>Email: info@utltimate-cms.in</p>
			</body>
			</html>
			";

			// Always set content-type when sending HTML email
			$headers = "MIME-Version: 1.0" . "\r\n";
			$headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

			// More headers
			$headers .= 'From: <ultimatecms@ultimate-cms.in>' . "\r\n";
			$headers .= 'Cc: support@ultimate-cms.in' . "\r\n";

			mail($to,$subject,$message,$headers);
			
			
		}else{
			//Execution Failed do something 
		}
	 }
	 //SQl Or Database Configuration is not correct
	 //Store the exeception message in a variable
	 catch(PDOException $ex){
		 //Printout the error message
		echo "A problem occured :" .$ex->getMessage(); 
	 }
		
		
 }else{
	 echo "No Value from Post Method";
 }


?>