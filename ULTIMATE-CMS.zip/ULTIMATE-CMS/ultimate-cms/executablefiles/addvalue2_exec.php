<?php

require('../webconfig/config.php');

//Check Either We are getting value using post method or not
if($_POST)
 {
	 //Get all the value using POST Method
	 $withoutajaxvalue_1=$_POST['withoutajaxvalue-1'];
	 $withoutajaxvalue_2=$_POST['withoutajaxvalue-2'];
	 $withoutajaxvalue_3=$_POST['withoutajaxvalue-3'];
	 $withoutajaxvalue_4=$_POST['withoutajaxvalue-4'];
	 //
	 
	 //Get Todays Date//
	 $joining_date= date('Y-m-d H:i:s');
	 //Date format https://www.w3schools.com/php/func_date_date_format.asp //
	 
	 //Create a Token with Unique value//
	 $text=str_replace(":","",$joining_date);
	 $text1=str_replace("-","",$text);
	 $text2=str_replace(" ","",$text1);
	 /*Add or Concatenate the data with unique value like email, phone, id etc*/
	 $text4=$text2.$withoutajaxvalue_2;
	 $text5=md5($text4);
	 $token="ULTIMATECMS".$text5;
	 //It can be used to send in email for email verification//
	 
	 //Create a Random 6 Digit Number for OTP
	 $otp=rand(100001,999999);
	 //
	 
	 //Exeception Handling Try the SQl to execute if it is correct everything inside try will happen
	 try {
	 //Prepare the SQL Statement
	 $stmt = $db_con->prepare("INSERT INTO `addinfowithoutajax_tb`(`field1`, `field2`, `field3`, `field4`) VALUES
	 (:withoutajaxvalue_1,:withoutajaxvalue_2,:withoutajaxvalue_3,:withoutajaxvalue_4)");
	   
	 //Bind all the variables into parameter to store the data
	   $stmt->bindParam(":withoutajaxvalue_1",$withoutajaxvalue_1);
	   $stmt->bindParam(":withoutajaxvalue_2",$withoutajaxvalue_2);
	   $stmt->bindParam(":withoutajaxvalue_3",$withoutajaxvalue_3);
	   $stmt->bindParam(":withoutajaxvalue_4",$withoutajaxvalue_4);
	   
   
     //Execute and check execution success or not
		if($stmt->execute())
		{
			//Execution Success do something 
			//Redirect the page where the value is submitted with a variable status and set the value success
			header("location: $base_url/addvalue/?status=success");
			
		}else{
			//Execution Failed do something 
			//Redirect the page where the value is submitted with a variable status and set the value failed
			header("location: $base_url/addvalue/?status=failed");
		}
	 }
	 //SQl Or Database Configuration is not correct
	 //Store the exeception message in a variable
	 catch(PDOException $ex){
		 //Printout the error message
		echo "A problem occured :" .$ex->getMessage(); 
	 }
		
		
 }else{
	 echo "No Value from Post Method";
 }


?>