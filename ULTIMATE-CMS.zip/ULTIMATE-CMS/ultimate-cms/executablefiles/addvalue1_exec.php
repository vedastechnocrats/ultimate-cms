<?php

require('../webconfig/config.php');

//Check Either We are getting value using post method or not
if($_POST)
 {
	 //Get all the value using POST Method
	 $ajax_value1=$_POST['ajax-value1'];
	 $ajax_value3=$_POST['ajax-value3'];
	 $ajax_value5=$_POST['ajax-value5'];
	 $ajax_value7=$_POST['ajax-value7'];
	 $ajax_value8=$_POST['ajax-value8'];
	 //
	 
	 //Get Todays Date//
	 $joining_date= date('Y-m-d H:i:s');
	 //Date format https://www.w3schools.com/php/func_date_date_format.asp //
	 
	 //Create a Token with Unique value//
	 $text=str_replace(":","",$joining_date);
	 $text1=str_replace("-","",$text);
	 $text2=str_replace(" ","",$text1);
	 /*Add or Concatenate the data with unique value like email, phone, id etc*/
	 $text4=$text2.$ajax_value1;
	 $text5=md5($text4);
	 $token="ULTIMATECMS".$text5;
	 //It can be used to send in email for email verification//
	 
	 //Create a Random 6 Digit Number for OTP
	 $otp=rand(100001,999999);
	 //
	 
	 //Exeception Handling Try the SQl to execute if it is correct everything inside try will happen
	 try {
	 //Prepare the SQL Statement
	 $stmt = $db_con->prepare("INSERT INTO `addinfowithajax_tb`(`field1`, `field2`, `field3`, `field4`, `field5`, `field6`) VALUES
	 (:ajax_value1,:ajax_value2,:ajax_value3,:ajax_value5,:ajax_value7,:ajax_value8)");
	   
	 //Bind all the variables into parameter to store the data
	   $stmt->bindParam(":ajax_value1",$ajax_value1);
	   $stmt->bindParam(":ajax_value2",$token);
	   $stmt->bindParam(":ajax_value3",$ajax_value3);
	   $stmt->bindParam(":ajax_value5",$ajax_value5);
	   $stmt->bindParam(":ajax_value7",$ajax_value7);
	   $stmt->bindParam(":ajax_value8",$ajax_value8);
	   
   
     //Execute and check execution success or not
		if($stmt->execute())
		{
			//Execution Success do something 
			
			
			//Get the ID of the Inserted Data
			$last_id = $db_con->lastInsertId();
			
			//Add the data from select tag which can input multiple data
			$stmt = $db_con->prepare("INSERT INTO `multiplevalue_tb`(`multifield`, `fieldid`) VALUES (:option,'$last_id')");
                 
				    //Loop Through all the values
                    foreach($_POST['ajax-value6'] as $option) {
						
						//Execute the data
                        $stmt->execute(array(':option' => $option));
                    }
                
			
			
			
		}else{
			//Execution Failed do something 
		}
	 }
	 //SQl Or Database Configuration is not correct
	 //Store the exeception message in a variable
	 catch(PDOException $ex){
		 //Printout the error message
		echo "A problem occured :" .$ex->getMessage(); 
	 }
		
		
 }else{
	 echo "No Value from Post Method";
 }


?>