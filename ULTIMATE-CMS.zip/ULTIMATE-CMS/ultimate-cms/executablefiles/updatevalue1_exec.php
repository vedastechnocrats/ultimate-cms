<?php

require('../webconfig/config.php');

//Check Either We are getting value using post method or not
if($_POST)
 {
	 //Get all the value using POST Method
	 //ID which will going to use as a factor to uniquely identify which row has to be updated
	 $tableid=$_POST['tableid'];
	 $field_value1=$_POST['field-value1'];
	 $field_value5=$_POST['field-value5'];
	 $field_value7=$_POST['field-value7'];
	 $field_value8=$_POST['field-value8'];
	 //
	 
	 try
  {
	//update data
    $sql1 = "UPDATE addinfowithajax_tb SET field1='$field_value1',field4='$field_value5',field5='$field_value7',field5='$field_value8' WHERE id='$tableid'";
    if($db_con->exec($sql1))
    {
		//Execution Success do something 
		//Redirect the page where the value is submitted with a variable status and set the value success
		header("location: $base_url/altermanagevalue/?status=successfullyupdated");
	}else{
		//Execution Failed do something 
		//Redirect the page where the value is submitted with a variable status and set the value failed
		header("location: $base_url/altermanagevalue/?status=failedtoupdate");
	}
  }catch(PDOException $e){
	  echo $e;
  }
 }