<!--Add Header Web Part Here-->
<?php include('webparts/header.php'); ?>
<!---->	

<!--Add Sidebar Web Part Here-->
<?php include('webparts/sidebar.php'); ?>
<!---->	
	  
<!--Website Content goes here--> 

      <div class="site-content">
        <div class="panel panel-default panel-table m-b-0">
          <div class="panel-heading">
            <h3 class="m-t-0 m-b-5">Column Filtering</h3>
			<h4><a href="<?php echo $base_url; ?>/altermanagevalue/">Alternate Version</a></h4>
          </div>
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-bordered">
                <thead>
                  <tr>
				    
				    <th>#</th>
                    <th>Field 1</th>
                    <th>Field 2</th>
                    <th>Field 3</th>
                    <th>Field 4</th>
                    <th>Field 5</th>
					<th>Field 6</th>
					<th></th>
				   </tr>
                </thead>
                <tbody>
				<!--Dynamically Generated Part from Database Using Ajax-->
				
				
                </tbody>
                
              </table>
			  <ul id="pagination" class="pagination-sm"></ul>
            </div>
          </div>
		  <!-- Edit Item Modal -->
		<div class="modal fade" id="edit-item" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">×</span></button>
		        <h4 class="modal-title" id="myModalLabel">Edit Item</h4>
		      </div>

		      <div class="modal-body">
		      		<form action="api/update.php" method="put">
		      			<input type="hidden" name="id" class="edit-id">

		      			<div class="form-group">
							<label class="control-label" for="title">Title:</label>
							<input type="text" name="title" class="form-control" data-error="Please enter title." required />
							<div class="help-block with-errors"></div>
						</div>

						<div class="form-group">
							<label class="control-label" for="title">Description:</label>
							<input type="text" name="description" class="form-control" data-error="Please enter description." required>
							<div class="help-block with-errors"></div>
						</div>

						<div class="form-group">
							<button type="submit" class="btn btn-primary crud-submit-edit">Submit</button>
						</div>

		      		</form>

		      </div>
		    </div>
		  </div>
		</div>
		<!-- -->
		
		
        </div>
      </div>
      <!---->
	  		
<!--Add Footer Web Part Here-->
<?php include('webparts/footer.php'); ?>
<!---->