<!--Add Header Web Part Here-->
<?php include('webparts/header.php'); ?>
<!---->	

<!--Add Sidebar Web Part Here-->
<?php include('webparts/sidebar.php'); ?>
<!---->	




<!--Website Content goes here-->  
    <div class="site-content">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Tutorials</h3>
          </div>
		  <div class="container">
		    <div class="row">
			<div class="col-md-4 col-sm-6">
			<iframe src="https://player.vimeo.com/video/230135493" width="100%" height="300" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
            </div>
			<div class="col-md-4 col-sm-6">
			
			</div>
			<div class="col-md-4 col-sm-6">
			
			</div>
			<div class="col-md-4 col-sm-6">
			
			</div>
			</div>
			<div class="row">
			<div class="col-md-4 col-sm-6">
			
			</div>
			<div class="col-md-4 col-sm-6">
			
			</div>
			<div class="col-md-4 col-sm-6">
			
			</div>
			<div class="col-md-4 col-sm-6">
			
			</div>
			</div>
		  </div>
		</div>
	</div>
</div>
<!--Add Footer Web Part Here-->
<?php include('webparts/footer.php'); ?>
<!---->