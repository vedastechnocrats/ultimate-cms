<?php
//Include database connection details
    require_once 'webconfig/config.php';
//Get the mode value
@$mode=$_POST["mode"];
echo $mode;
//check the checkbox is checked or not
if(empty($mode)){
	//Login using session as user doesnot want to keep him/herself loggedin
	
	//Code to login using session
	
	//Start session
	session_start();
 
	
    
	
 
	//Function to sanitize values received from the form. Prevents SQL injection
	
 
	//Sanitize the POST values
	$username = mysql_real_escape_string($_POST['username']);
	$password = mysql_real_escape_string($_POST['password']);
	
	$sql = "SELECT * FROM admin_tbl where username='$username'";
	$result = $conn->query($sql);

    if ($result->num_rows > 0) {
    // output data of each row
    
	//If there are input validations, redirect back to the login form
	//Data Found User Exist
	
	//Create query
	$qry="SELECT * FROM admin_tbl WHERE username='$username' AND password='$password'";
	$result=mysql_query($qry);
 
	//Check whether the query was successful or not
	if($result) {
		if(mysql_num_rows($result) > 0) {
			//Login Successful
			session_regenerate_id();
			$member = mysql_fetch_assoc($result);
			$_SESSION['SESSUCADMIN_MEMBER_ID'] = $member['id'];
			$_SESSION['SESSUCADMIN_USERNAME'] = $member['username'];
			$_SESSION['SESSUCADMIN_PASSWORD'] = $member['password'];
			
			session_write_close();
			
			//Signin Log insert here [Optional Part]
			@ $details = json_decode(file_get_contents("http://ipinfo.io/{$_SERVER['REMOTE_ADDR']}/json"));
  @ $hostname=gethostbyaddr($_SERVER['REMOTE_ADDR']);
  
  // Get the query string from the URL.
  $QUERY_STRING = preg_replace("%[^/a-zA-Z0-9@,_=]%", '', $_SERVER['QUERY_STRING']);
  
  // Write the ip address and info to file.
  @ $fileHandle = fopen($outputWebBug, "a");
  if ($fileHandle)
  {
    $string ='"'.$QUERY_STRING.'","' // everything after "?" in the URL
      .$_SERVER['REMOTE_ADDR'].'","' // ip address
      .$hostname.'","' // hostname
      .$_SERVER['HTTP_USER_AGENT'].'","' // browser and operating system
      .$_SERVER['HTTP_REFERER'].'","' // where they got the link for this page
	  //Wont work in localhost activate in live server
      //.$details->loc.'","' // latitude, longitude
      //.$details->org.'","' // internet service provider
     // .$details->city.'","'  // city
      //.$details->region.'","' // state
      //.$details->country.'","' // country
      .date("D dS M,Y h:i a").'"' // date
      ."\n"
      ;
     $write = fputs($fileHandle, $string);
    @ fclose($fileHandle);
  }

  $string = '<code>'
    .'<p>'.$QUERY_STRING.'</p><p>IP address:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
    .$_SERVER['REMOTE_ADDR'].'</p><p>Hostname:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
    .$hostname.'</p><p>Browser and OS:&nbsp;'
    .$_SERVER['HTTP_USER_AGENT'].'</p><p>'
    .$_SERVER['HTTP_REFERER'].'</p><p>Coordinates:&nbsp;&nbsp;&nbsp;&nbsp;'
    //.$details->loc.'</p><p>ISP provider:&nbsp;&nbsp;&nbsp;'
    //.$details->org.'</p><p>City:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
    //.$details->city.'</p><p>State:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
    //.$details->region.'</p><p>Country:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
    //.$details->country.'</p><p>Date:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
    .date("D dS M,Y h:i a").'</p></code>'
    ;
	//Get Todays Date//
	 $login_date= date('Y-m-d H:i:s');
	 //Date format https://www.w3schools.com/php/func_date_date_format.asp //
	 
	 $login_using="Session";
	
	try {
	 //Prepare the SQL Statement
	 $stmt = $db_con->prepare("INSERT INTO `adminloginlog_tbl`(`loggedinusername`, `relatedinfo`, `dateoflogin`, `loginusing`) VALUES
	 (:value1,:value2,:value3,:value5)");
	   
	 //Bind all the variables into parameter to store the data
	   $stmt->bindParam(":value1",$username);
	   $stmt->bindParam(":value2",$string);
	   $stmt->bindParam(":value3",$login_date);
	   $stmt->bindParam(":value5",$login_using);

	   
   
     //Execute and check execution success or not
		if($stmt->execute())
		{
			//Log Data Added Successfully
		}
	}catch(PDOException $ex){
		 //Printout the error message
		echo "A problem occured :" .$ex->getMessage(); 
	 }
	
	//
			
				header("location: $base_url/?status=loginsuccess");
			
			
			exit();
		}else {
			//Login failed
			
				session_write_close();
				header("location: $base_url/?status=failed");
				exit();
			
		}
	}else {
		die("Query failed");
	}
	
	
} else {
	
   header("location: $base_url/?status=userdoesnotexist");
}

//	
	
	
}else{
	//Login using cookie as user wants to keep him/herself loggedin
	
	//Code to login using cookie
	$user_name = $_POST['username'];
    $user_password = $_POST['password'];

        
		//Select Query
		
    $stmt = $db_con->prepare("SELECT * FROM admin_tbl where username='$user_name' and password='$user_password'");
    $stmt->execute();
        $count = $stmt->rowCount();
		
		//user doesnot exist or wrong username or password
		if($count==0){
		header("location: $base_url/login/?status=failed");
		}else{
			
		//user exist login success
		//Fetching rows
        while($row=$stmt->fetch(PDO::FETCH_ASSOC))
    {
		
		//Extract data
            extract($row);
			
		
			$username=$username;
			$password=$password;
			
			
			
						//Signin Log insert here [Optional Part]
			@ $details = json_decode(file_get_contents("http://ipinfo.io/{$_SERVER['REMOTE_ADDR']}/json"));
  @ $hostname=gethostbyaddr($_SERVER['REMOTE_ADDR']);
  
  // Get the query string from the URL.
  $QUERY_STRING = preg_replace("%[^/a-zA-Z0-9@,_=]%", '', $_SERVER['QUERY_STRING']);
  
  // Write the ip address and info to file.
  @ $fileHandle = fopen($outputWebBug, "a");
  if ($fileHandle)
  {
    $string ='"'.$QUERY_STRING.'","' // everything after "?" in the URL
      .$_SERVER['REMOTE_ADDR'].'","' // ip address
      .$hostname.'","' // hostname
      .$_SERVER['HTTP_USER_AGENT'].'","' // browser and operating system
      .$_SERVER['HTTP_REFERER'].'","' // where they got the link for this page
      //.$details->loc.'","' // latitude, longitude
      //.$details->org.'","' // internet service provider
      //.$details->city.'","'  // city
      //.$details->region.'","' // state
      //.$details->country.'","' // country
      .date("D dS M,Y h:i a").'"' // date
      ."\n"
      ;
     $write = fputs($fileHandle, $string);
    @ fclose($fileHandle);
  }

  $string = '<code>'
    .'<p>'.$QUERY_STRING.'</p><p>IP address:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
    .$_SERVER['REMOTE_ADDR'].'</p><p>Hostname:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
    .$hostname.'</p><p>Browser and OS:&nbsp;'
    .$_SERVER['HTTP_USER_AGENT'].'</p><p>'
    .$_SERVER['HTTP_REFERER'].'</p><p>Coordinates:&nbsp;&nbsp;&nbsp;&nbsp;'
    //.$details->loc.'</p><p>ISP provider:&nbsp;&nbsp;&nbsp;'
    //.$details->org.'</p><p>City:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
    //.$details->city.'</p><p>State:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
    //.$details->region.'</p><p>Country:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
    //.$details->country.'</p><p>Date:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'
    .date("D dS M,Y h:i a").'</p></code>'
    ;
	//Get Todays Date//
	 $login_date= date('Y-m-d H:i:s');
	 //Date format https://www.w3schools.com/php/func_date_date_format.asp //
	 
	 $login_using="Cookie";
	
	try {
	 //Prepare the SQL Statement
	 $stmt = $db_con->prepare("INSERT INTO `adminloginlog_tbl`(`loggedinusername`, `relatedinfo`, `dateoflogin`, `loginusing`) VALUES
	 (:value1,:value2,:value3,:value5)");
	   
	 //Bind all the variables into parameter to store the data
	   $stmt->bindParam(":value1",$username);
	   $stmt->bindParam(":value2",$string);
	   $stmt->bindParam(":value3",$login_date);
	   $stmt->bindParam(":value5",$login_using);

	   
   
     //Execute and check execution success or not
		if($stmt->execute())
		{
			//Log Data Added Successfully
		}
	}catch(PDOException $ex){
		 //Printout the error message
		echo "A problem occured :" .$ex->getMessage(); 
	 }
	
	//
			
			
			
			
			
			
        setcookie("ucadminusername",$username,time()+31556926,'/');
        setcookie("ucadminpassword",$password,time()+31556926,'/');
        header("location: $base_url/?status=loginsuccess");
			
			
			
			
    }
	
	}
//
}

?>