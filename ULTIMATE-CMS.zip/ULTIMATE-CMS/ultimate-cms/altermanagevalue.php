<!--Add Header Web Part Here-->
<?php include('webparts/header.php'); ?>
<!---->	

<!--Add Sidebar Web Part Here-->
<?php include('webparts/sidebar.php'); ?>
<!---->	
	  
<!--Website Content goes here--> 
<?php
//put a @ symbol before the line so that it cant throw a value cant find error on that line
//@ Only hide the warning it doesnot resolve it
@$status=$_GET['status'];
if($status=="successfullyupdated"){
	//url have the value success which means execution is a success show a success message here 
	?>
	<button type="button" style="display:none;" id="statusmodal" class="btn btn-outline-success m-w-120" data-toggle="modal" data-target="#successModal">Success</button>
                
	                <div id="successModal" class="modal fade" tabindex="-1" role="dialog">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">
                            <i class="zmdi zmdi-close"></i>
                          </span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="text-center">
                          <div class="text-success">
                            <i class="zmdi zmdi-check zmdi-hc-5x"></i>
                          </div>
                          <h3>Success</h3>
                          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            <br>Pellentesque lacinia non massa a euismod.</p>
                          <div class="m-y-30">
                            <button type="button" data-dismiss="modal" class="btn btn-success">Continue</button>
                            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer"></div>
                    </div>
                  </div>
                </div>
				<?php
}else if($status=="failedtoupdate"){
	//url have the value success which means execution is a success show a success message here 
	?>
	<button type="button" style="display:none;" id="statusmodal" class="btn btn-outline-success m-w-120" data-toggle="modal" data-target="#dangerModal">Failed</button>
    
	                <div id="dangerModal" class="modal fade" tabindex="-1" role="dialog">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">
                            <i class="zmdi zmdi-close"></i>
                          </span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="text-center">
                          <div class="text-danger">
                            <i class="zmdi zmdi-alert-triangle zmdi-hc-5x"></i>
                          </div>
                          <h3>Danger</h3>
                          <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.
                            <br>Pellentesque lacinia non massa a euismod.</p>
                          <div class="m-y-30">
                            <button type="button" data-dismiss="modal" class="btn btn-danger">Continue</button>
                            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer"></div>
                    </div>
                  </div>
                </div>
				<?php
}
?>

      <div class="site-content">
        <div class="panel panel-default panel-table m-b-0">
          <div class="panel-heading">
            <h3 class="m-t-0 m-b-5">Column Filtering</h3>
          </div>
          <div class="panel-body">
            <div class="table-responsive">
              <table class="table table-striped table-bordered dataTable" id="table-3">
                <thead>
                  <tr>
				    <th></th>
				    <th>#</th>
                    <th>Field 1</th>
                    <th>Field 2</th>
                    <th>Field 3</th>
                    <th>Field 4</th>
                    <th>Field 5</th>
					<th>Field 6</th>
				   </tr>
                </thead>
                <tbody>
				<!--Dynamically Generated Part from Database-->
				
				<!--Select Query to Show Data-->
				<?php
					//Select Query Change the table name as per the need						
					$stmt = $db_con->prepare("SELECT * FROM `addinfowithajax_tb` ");
					//Execute the Query
					$stmt->execute();
					//Count How many Value returened use this $count variable wherver needed
						$count=$stmt->rowCount();
						//Fetch the rows
							while($row=$stmt->fetch(PDO::FETCH_ASSOC))
								{
									//Extract the rows
									extract($row);
										//Assign the value to different variables. Use same name specified in table		
										$id=$id;
										$field1=$field1;
										$field2=$field2;
										$field3=$field3;
										$field4=$field4;
										$field5=$field5;
										$field6=$field6;
				?>								
                  <tr>
				    <td>
                        <a href="javascript:void(0);"  class="btn btn-warning" data-toggle="modal" data-target="#editModal<?php echo $id; ?>"><i class="fa fa-edit"></i></a>
                        <a href="javascript:void(0);"  class="btn btn-danger" onclick="return confirm('Are you sure to delete data?')?userAction('delete','<?php echo $id; ?>'):false;"><i class="fa fa-trash"></i></a>
                    </td>
				    <td><?php echo $id; ?></td>
                    <td><?php echo $field1; ?></td>
                    <td><?php echo $field2; ?></td>
                    <td><?php echo $field3; ?></td>
                    <td><?php echo $field4; ?></td>
                    <td><?php echo $field5; ?></td>
					<td><?php echo $field6; ?></td>
				 </tr>
				 
				 
				 <!--Popup Edit Form-->
				 <!-- Modal -->
				<div id="editModal<?php echo $id; ?>" class="modal fade" role="dialog">
				  <div class="modal-dialog">

					<!-- Modal content-->
					<div class="modal-content">
					  <div class="modal-header">
						<button type="button" class="close" data-dismiss="modal">&times;</button>
						<h4 class="modal-title">Edit Information for <?php echo $field1; ?></h4>
					  </div>
					  <div class="modal-body">
						<form class="form-horizontal" id="withoutusing-ajax" method="post" action="<?php echo $base_url; ?>/executablefiles/updatevalue1_exec.php">
						<!--Echo the primary key id to update the correct info-->
						<input type="hidden" value="<?php echo $id; ?>" name="tableid" id="tableid">
							<div class="form-group">
								<label class="col-sm-3 control-label" for="form-control-5">Placeholder Input</label>
								<div class="col-sm-9">
								  <input id="ajax-value1" value="<?php echo $field1; ?>" name="field-value1" class="form-control" type="email" placeholder="Placeholder input text"  required>
								</div>
							</div>

							<div class="form-group">
							<label for="form-control-1" class="col-sm-3  control-label">Single select box</label>
							<div class="col-md-9">
							  <select id="ajax-value5"  name="field-value5" style="width:100%" class="form-control" data-plugin="select2" data-options="{ theme: bootstrap }">
								<?php
								if($field4=="option1"){
									?>
								<option value="option1" selected>HTML</option>
								<option value="option2">CSS</option>
								<option value="option3">Javascript</option>
								<option value="option4">PHP</option>
								<option value="option5">Bootstrap</option>
									
									<?php
								}else if($field4=="option2"){
									?>
								<option value="option1">HTML</option>
								<option value="option2" selected>CSS</option>
								<option value="option3">Javascript</option>
								<option value="option4">PHP</option>
								<option value="option5">Bootstrap</option>
									
									<?php
								}else if($field4=="option3"){
									?>
								<option value="option1">HTML</option>
								<option value="option2">CSS</option>
								<option value="option3" selected>Javascript</option>
								<option value="option4">PHP</option>
								<option value="option5">Bootstrap</option>
									
									<?php
								}else if($field4=="option4"){
									?>
									
								<option value="option1">HTML</option>
								<option value="option2">CSS</option>
								<option value="option3">Javascript</option>
								<option value="option4" selected>PHP</option>
								<option value="option5">Bootstrap</option>
									
									<?php
								}else if($field4=="option5"){
									?>
									
								<option value="option1">HTML</option>
								<option value="option2">CSS</option>
								<option value="option3">Javascript</option>
								<option value="option4">PHP</option>
								<option value="option5" selected>Bootstrap</option>
									
									<?php
								}else{
								?>
                                <option value="option1">HTML</option>
								<option value="option2">CSS</option>
								<option value="option3">Javascript</option>
								<option value="option4">PHP</option>
								<option value="option5">Bootstrap</option>

                                <?php								
								}
								?>
								
							  </select>
							</div>
						  </div>
						  <div class="form-group">
								<label class="col-sm-3 control-label" for="form-control-5">Date Picker</label>
								<div class="col-sm-9">
								  <input class="form-control datepicker_recurring_start" value="<?php echo $field5; ?>" name="field-value7" id="ajax-value7" type="text" placeholder="Placeholder input text">
								</div>
							</div>
							<div class="form-group">
								<label class="col-sm-3 control-label" for="form-control-5">Time Picker</label>
								<div class="col-sm-9">
								  <input class="form-control timepicker_recurring_start" value="<?php echo $field6; ?>" type="text" name="field-value8" id="ajax-value8" placeholder="Placeholder input text">
								</div>
							</div>
							<div class="form-group">
								<div class="col-md-offset-3 col-sm-9">
								 <button type="submit" class="btn btn-primary m-w-120" id="submit-button" > Primary</button>
								
								</div>
							</div>
						  </form>
					  </div>
					  <div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
					  </div>
					</div>

				  </div>
				</div>
				 <!-- -->
				 
				<?php
                                }
                ?>								
				<!--  -->  
				  
                <!-- -->  
                </tbody>
                <tfoot>
                  <tr>
				    <th></th>
                    <th>#</th>
                    <th>Field 1</th>
                    <th>Field 2</th>
                    <th>Field 3</th>
                    <th>Field 4</th>
                    <th>Field 5</th>
					<th>Field 6</th>
					
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>
        </div>
      </div>
      <!---->
	  
<!--Add Footer Web Part Here-->
<?php include('webparts/footer.php'); ?>
<!---->