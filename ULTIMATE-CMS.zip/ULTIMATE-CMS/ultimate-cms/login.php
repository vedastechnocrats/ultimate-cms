<?php require ('webconfig/config.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description" content="">
    <title>Ultimate CMS</title>
    <link rel="apple-touch-icon" sizes="180x180" href="apple-touch-icon.html">
    <link rel="icon" type="image/png" href="<?php echo $base_url; ?>/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="<?php echo $base_url; ?>/favicon-16x16.png" sizes="16x16">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/vendor.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/cosmos.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/application.min.css">
	</head>
  <body class="authentication-body">
  
  
  <!--Get the value from URL and set it to a variable to check whether execution is successful or not-->
<?php
//put a @ symbol before the line so that it cant throw a value cant find error on that line
//@ Only hide the warning it doesnot resolve it
@$status=$_GET['status'];
if($status=="loginagain"){
	//url have the value success which means execution is a success show a success message here 
	?>
	<button type="button" style="display:none;" id="statusmodal" class="btn btn-outline-success m-w-120" data-toggle="modal" data-target="#infoModal3">Success</button>
                
	            <div id="infoModal3" class="modal fade" tabindex="-1" role="dialog">
                  <div class="modal-dialog">
                    <div class="modal-content bg-info">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">
                            <i class="zmdi zmdi-close"></i>
                          </span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="text-center">
                          <div>
                            <i class="zmdi zmdi-lock zmdi-hc-5x"></i>
                          </div>
                          <h3>Welcome to Ultimate CMS</h3>
                          <p>Please Login to your dashboard</p>
                          <div class="m-y-30">
                            <button type="button" data-dismiss="modal" class="btn btn-default">Continue</button>
                            <button type="button" data-dismiss="modal" class="btn btn-info">Close</button>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer"></div>
                    </div>
                  </div>
                </div>
				<?php
}else if($status=="logoutsuccess"){
	//url have the value success which means execution is a success show a success message here 
	?>
	<button type="button" style="display:none;" id="statusmodal" class="btn btn-outline-success m-w-120" data-toggle="modal" data-target="#dangerModal">Failed</button>
    
	                <div id="dangerModal" class="modal fade" tabindex="-1" role="dialog">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">
                            <i class="zmdi zmdi-close"></i>
                          </span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="text-center">
                          <div class="text-danger">
                            <i class="zmdi zmdi-alert-triangle zmdi-hc-5x"></i>
                          </div>
                          <h3>Good Bye. Have a nice day</h3>
                          <p>You are successfully loggedout from your dashboard</p>
                          <div class="m-y-30">
                            <button type="button" data-dismiss="modal" class="btn btn-danger">Continue</button>
                            <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer"></div>
                    </div>
                  </div>
                </div>
				<?php
}else if($status=="failed"){
?>
<button type="button" style="display:none;" id="statusmodal" class="btn btn-outline-success m-w-120" data-toggle="modal" data-target="#warningModal2">Upload Success</button>
    
                 <div id="warningModal2" class="modal fade" tabindex="-1" role="dialog">
                  <div class="modal-dialog">
                    <div class="modal-content bg-warning">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">
                            <i class="zmdi zmdi-close"></i>
                          </span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="text-center">
                          <div>
                            <i class="zmdi zmdi-alert-circle-o zmdi-hc-5x"></i>
                          </div>
                          <h3>Login Failed</h3>
                          <p>Wrong Username or Password</p>
                          <div class="m-y-30">
                            <button type="button" data-dismiss="modal" class="btn btn-default">Continue</button>
                            <button type="button" data-dismiss="modal" class="btn btn-warning">Close</button>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer"></div>
                    </div>
                  </div>
                </div>






<?php
}
?>
<!-- -->
  
  
  
    <div class="container-fluid">
      <div class="authentication-header m-b-30">
        <div class="clearfix">
          <div class="pull-left">
            <a class="authentication-logo" href="<?php echo $base_url; ?>/">
              <img src="<?php echo $base_url; ?>/img/logo.png" alt="" height="25">
              <span>Ultimate CMS</span>
            </a>
          </div>
          <div class="pull-right">
            <a href="<?php echo $base_url; ?>/register/" class="btn btn-outline-info">Sign up</a>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-sm-4 col-sm-offset-4">
          <div class="authentication-content m-b-30">
            <h3 class="m-t-0 m-b-30 text-center">You look great today!</h3>
            <form method="post" action="<?php echo $base_url; ?>/login_exec.php">
              <div class="form-group">
                <label for="form-control-1">Username</label>
                <input type="text" class="form-control" name="username" readonly onfocus="this.removeAttribute('readonly');" id="form-control-1" placeholder="Username">
              </div>
              <div class="form-group">
                <label for="form-control-2">Password</label>
                <input type="password" class="form-control" name="password" readonly onfocus="this.removeAttribute('readonly');" placeholder="Password">
              </div>
              <div class="form-group">
                <label class="custom-control custom-control-info custom-checkbox active">
                  <input class="custom-control-input" type="checkbox" name="mode" checked="checked">
                  <span class="custom-control-indicator"></span>
                  <span class="custom-control-label">Keep me signed in</span>
                </label>
                <a href="<?php echo $base_url; ?>/forget-password/" class="text-info pull-right">Forgot password?</a>
              </div>
              <button type="submit" class="btn btn-info btn-block">Submit</button>
            </form>
          </div>
        </div>
      </div>
      <div class="authentication-footer">
        <span class="text-muted">Need help? Contact us <a href="mailto:support@ultimate-cms.in" target="_blank">support@ultimate-cms.in</a></span>
      </div>
    </div>
    <script src="<?php echo $base_url; ?>/js/vendor.min.js"></script>
    <script src="<?php echo $base_url; ?>/js/cosmos.min.js"></script>
    <script src="<?php echo $base_url; ?>/js/application.min.js"></script>
	<!--Load the Modal in Page Load-->
	<script type="text/javascript">
		$(document).ready(function(){
			$("#statusmodal").trigger('click'); 
		});
    </script>
    <!-- -->
  </body>

</html>