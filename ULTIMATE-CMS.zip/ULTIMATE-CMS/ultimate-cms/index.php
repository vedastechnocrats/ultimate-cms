<!--Add Header Web Part Here-->
<?php include('webparts/header.php'); ?>
<!---->	

<!--Add Sidebar Web Part Here-->
<?php include('webparts/sidebar.php'); ?>
<!---->	
<?php
//put a @ symbol before the line so that it cant throw a value cant find error on that line
//@ Only hide the warning it doesnot resolve it
@$status=$_GET['status'];
if($status=="loginsuccess"){
	//url have the value success which means execution is a success show a success message here 
	?>
	<button type="button" style="display:none;" id="statusmodal" class="btn btn-outline-success m-w-120" data-toggle="modal" data-target="#infoModal3">Success</button>
                
	            <div id="infoModal3" class="modal fade" tabindex="-1" role="dialog">
                  <div class="modal-dialog">
                    <div class="modal-content bg-info">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">
                            <i class="zmdi zmdi-close"></i>
                          </span>
                        </button>
                      </div>
                      <div class="modal-body">
                        <div class="text-center">
                          <div>
                            <i class="zmdi zmdi-favorite zmdi-hc-5x"></i>
                          </div>
                          <h3>Welcome to Ultimate CMS</h3>
                          <p>Enjoy all features in your dashboard</p>
                          <div class="m-y-30">
                            <button type="button" data-dismiss="modal" class="btn btn-default">Continue</button>
                            <button type="button" data-dismiss="modal" class="btn btn-info">Close</button>
                          </div>
                        </div>
                      </div>
                      <div class="modal-footer"></div>
                    </div>
                  </div>
                </div>
				<?php
}
?>	  
<!--Website Content goes here-->  
	  
      <div class="site-content">
        <div class="row">
          <div class="col-md-4 col-sm-5">
            <div class="widget widget-tile-2 bg-primary m-b-30">
              <div class="wt-content p-a-20 p-b-50">
                <div class="wt-title">New users
                  <span class="t-caret text-success">
                    <i class="zmdi zmdi-caret-up"></i>
                  </span>
                </div>
                <div class="wt-number">175</div>
                <div class="wt-text">Updated today at 14:57</div>
              </div>
              <div class="wt-icon">
                <i class="zmdi zmdi-accounts"></i>
              </div>
              <div class="wt-chart">
                <span id="peity-chart-1">7,3,8,4,4,8,10,3,4,5,9,2,5,1,4,2,9,8,2,1</span>
              </div>
            </div>
            <div class="widget widget-tile-2 bg-warning m-b-30">
              <div class="wt-content p-a-20 p-b-50">
                <div class="wt-title">Sales</div>
                <div class="wt-number">$ 47,855</div>
                <div class="wt-text">+17% from previous period</div>
              </div>
              <div class="wt-icon">
                <i class="zmdi zmdi-shopping-basket"></i>
              </div>
              <div class="wt-chart">
                <span id="peity-chart-2">7,3,8,4,4,8,10,3,4,5,9,2,5,1,4,2,9,8,5,9</span>
              </div>
            </div>
            <div class="widget widget-tile-2 bg-danger m-b-30">
              <div class="wt-content p-a-20 p-b-50">
                <div class="wt-title">CPU usage</div>
                <div class="wt-number">75%</div>
                <div class="wt-text">Updated: 09:26 AM</div>
              </div>
              <div class="wt-icon">
                <i class="zmdi zmdi-email-open"></i>
              </div>
              <div class="wt-chart">
                <span id="peity-chart-3">0,1,2,3,2,1,5,6,7,3,8,9,10,9,8,12,15,11,15,17</span>
              </div>
            </div>
          </div>
          <div class="col-md-8 col-sm-7">
            <div class="panel panel-default panel-table">
              <div class="panel-heading">
                <div class="panel-tools">
                  <a href="#" class="tools-icon">
                    <i class="zmdi zmdi-refresh"></i>
                  </a>
                  <a href="#" class="tools-icon">
                    <i class="zmdi zmdi-close"></i>
                  </a>
                </div>
                <h3 class="panel-title">Recent purchases</h3>
                <div class="panel-subtitle">+23% from previous period</div>
              </div>
              <div class="panel-body">
                <div class="clearfix">
                  <div class="btn-group pull-left" data-toggle="buttons">
                    <label class="btn btn-outline-primary active">
                      <input type="radio" name="buttonRadios" id="buttonRadios1" autocomplete="off" checked="checked"> Day
                    </label>
                    <label class="btn btn-outline-primary">
                      <input type="radio" name="buttonRadios" id="buttonRadios2" autocomplete="off"> Week
                    </label>
                    <label class="btn btn-outline-primary">
                      <input type="radio" name="buttonRadios" id="buttonRadios3" autocomplete="off"> Month
                    </label>
                  </div>
                  <div class="pull-right m-t-10">
                    <span class="m-r-15">
                      <i class="zmdi zmdi-circle text-primary m-r-5"></i> Development</span>
                    <span class="m-r-15">
                      <i class="zmdi zmdi-circle text-warning m-r-5"></i> SEO</span>
                    <span class="m-r-15">
                      <i class="zmdi zmdi-circle text-danger m-r-5"></i> Design</span>
                  </div>
                </div>
              </div>
              <div id="advanced" class="chartist-animated" style="height: 358px"></div>
            </div>
          </div>
        </div>
        <div class="panel panel-default panel-table">
          <div class="panel-heading">
            <div class="panel-tools">
              <a href="#" class="tools-icon">
                <i class="zmdi zmdi-refresh"></i>
              </a>
              <a href="#" class="tools-icon">
                <i class="zmdi zmdi-close"></i>
              </a>
            </div>
            <h3 class="panel-title">Conversions map</h3>
            <div class="panel-subtitle">1 Feb 2017 - 17 Jul 2017</div>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-sm-8">
                <div id="vector-map" style="height: 350px; width: 100%"></div>
              </div>
              <div class="col-sm-4">
                <div class="switches-stacked m-b-30">
                  <label class="switch switch-primary m-b-15">
                    <input type="checkbox" name="newsletter" class="s-input" checked="checked">
                    <span class="s-content">
                      <span class="s-track"></span>
                      <span class="s-handle"></span>
                    </span>
                    <span class="s-desc text-muted">Mobiles</span>
                  </label>
                  <label class="switch switch-primary">
                    <input type="checkbox" name="newsletter" class="s-input">
                    <span class="s-content">
                      <span class="s-track"></span>
                      <span class="s-handle"></span>
                    </span>
                    <span class="s-desc text-muted">Desktop</span>
                  </label>
                </div>
                <p>Google AdWords
                  <span class="pull-right text-muted">80%</span>
                </p>
                <div class="progress progress-xs m-b-20">
                  <div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                    <span class="sr-only">80% Complete (success)</span>
                  </div>
                </div>
                <p>Facebook
                  <span class="pull-right text-muted">57%</span>
                </p>
                <div class="progress progress-xs m-b-20">
                  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="57" aria-valuemin="0" aria-valuemax="100" style="width: 57%">
                    <span class="sr-only">57% Complete (success)</span>
                  </div>
                </div>
                <p>SEO
                  <span class="pull-right text-muted">60%</span>
                </p>
                <div class="progress progress-xs m-b-20">
                  <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%">
                    <span class="sr-only">60% Complete (success)</span>
                  </div>
                </div>
                <p>Instagram
                  <span class="pull-right text-muted">23%</span>
                </p>
                <div class="progress progress-xs m-b-20">
                  <div class="progress-bar progress-bar-info" role="progressbar" aria-valuenow="23" aria-valuemin="0" aria-valuemax="100" style="width: 23%">
                    <span class="sr-only">23% Complete (success)</span>
                  </div>
                </div>
                <button type="button" class="btn btn-outline-primary btn-block">Details</button>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-6">
            <div class="panel panel-default panel-table">
              <div class="panel-heading">
                <div class="panel-tools">
                  <a href="#" class="tools-icon">
                    <i class="zmdi zmdi-refresh"></i>
                  </a>
                  <a href="#" class="tools-icon">
                    <i class="zmdi zmdi-close"></i>
                  </a>
                </div>
                <h3 class="panel-title">Top active pages</h3>
                <div class="panel-subtitle">At the moment 440 active visitors on site</div>
              </div>
              <div class="table-responsive">
                <table class="table table-borderless table-condensed m-b-0">
                  <thead>
                    <tr>
                      <th>#</th>
                      <th>Url</th>
                      <th>Visitors</th>
                      <th>New users</th>
                      <th>Pageviews</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td class="col-xs-1">1.</td>
                      <td class="col-xs-3">
                        <a href="#" class="text-primary">/pricing.html</a>
                      </td>
                      <td class="col-xs-3">
                        10 691
                      </td>
                      <td class="col-xs-3">
                        80%
                        <i class="zmdi zmdi-arrow-left-bottom"></i>
                      </td>
                      <td>
                        <span data-chart="peity" data-type="line">3,4,0,6,4,9,7,3,5,2</span>
                      </td>
                    </tr>
                    <tr>
                      <td class="col-xs-1">2.</td>
                      <td class="col-xs-3">
                        <a href="#" class="text-primary">/features.html</a>
                      </td>
                      <td class="col-xs-3">
                        3 569
                      </td>
                      <td class="col-xs-3">
                        69%
                        <i class="zmdi zmdi-arrow-left-bottom"></i>
                      </td>
                      <td>
                        <span data-chart="peity" data-type="line">5,1,5,6,5,8,3,4,5,2</span>
                      </td>
                    </tr>
                    <tr>
                      <td class="col-xs-1">3.</td>
                      <td class="col-xs-3">
                        <a href="#" class="text-primary">/team.html</a>
                      </td>
                      <td class="col-xs-3">
                        1 058
                      </td>
                      <td class="col-xs-3">
                        17%
                        <i class="zmdi zmdi-arrow-right-top"></i>
                      </td>
                      <td>
                        <span data-chart="peity" data-type="line">5,3,4,6,2,4,8,4,3,1</span>
                      </td>
                    </tr>
                    <tr>
                      <td class="col-xs-1">4.</td>
                      <td class="col-xs-3">
                        <a href="#" class="text-primary">/portfolio.html</a>
                      </td>
                      <td class="col-xs-3">
                        579
                      </td>
                      <td class="col-xs-3">
                        43%
                        <i class="zmdi zmdi-arrow-left-bottom"></i>
                      </td>
                      <td>
                        <span data-chart="peity" data-type="line">5,4,9,5,6,8,9,3,5,7</span>
                      </td>
                    </tr>
                    <tr>
                      <td class="col-xs-1">5.</td>
                      <td class="col-xs-3">
                        <a href="#" class="text-primary">/about.html</a>
                      </td>
                      <td class="col-xs-3">
                        258
                      </td>
                      <td class="col-xs-3">
                        30%
                        <i class="zmdi zmdi-arrow-right-top"></i>
                      </td>
                      <td>
                        <span data-chart="peity" data-type="line">5,3,9,6,5,9,7,3,5,2</span>
                      </td>
                    </tr>
                    <tr>
                      <td class="col-xs-1">6.</td>
                      <td class="col-xs-3">
                        <a href="#" class="text-primary">/blog.html</a>
                      </td>
                      <td class="col-xs-3">
                        150
                      </td>
                      <td class="col-xs-3">
                        46%
                        <i class="zmdi zmdi-arrow-right-top"></i>
                      </td>
                      <td>
                        <span data-chart="peity" data-type="line">8,3,10,6,7,9,2,4,5,2</span>
                      </td>
                    </tr>
                    <tr>
                      <td class="col-xs-1">7.</td>
                      <td class="col-xs-3">
                        <a href="#" class="text-primary">/privacy.html</a>
                      </td>
                      <td class="col-xs-3">
                        50
                      </td>
                      <td class="col-xs-3">
                        14%
                        <i class="zmdi zmdi-arrow-left-bottom"></i>
                      </td>
                      <td>
                        <span data-chart="peity" data-type="line">5,3,1,6,2,9,2,3,5,2</span>
                      </td>
                    </tr>
                    <tr>
                      <td class="col-xs-1">8.</td>
                      <td class="col-xs-3">
                        <a href="#" class="text-primary">/jobs.html</a>
                      </td>
                      <td class="col-xs-3">
                        14
                      </td>
                      <td class="col-xs-3">
                        53%
                        <i class="zmdi zmdi-arrow-left-bottom"></i>
                      </td>
                      <td>
                        <span data-chart="peity" data-type="line">5,3,1,6,2,9,2,3,5,2</span>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="col-md-6">
            <div class="panel panel-default panel-table">
              <div class="panel-heading">
                <div class="panel-tools">
                  <a href="#" class="tools-icon">
                    <i class="zmdi zmdi-refresh"></i>
                  </a>
                  <a href="#" class="tools-icon">
                    <i class="zmdi zmdi-close"></i>
                  </a>
                </div>
                <h3 class="panel-title">File uploads</h3>
                <div class="panel-subtitle">Last upload 5 min ago</div>
              </div>
              <div class="panel-body">
                <div class="row gutter-sm m-b-20">
                  <div class="col-xs-3">
                    <a href="#">
                      <img src="img/square-photos/1.jpg" class="img-responsive">
                    </a>
                  </div>
                  <div class="col-xs-3">
                    <a href="#">
                      <img src="img/square-photos/2.jpg" class="img-responsive">
                    </a>
                  </div>
                  <div class="col-xs-3">
                    <a href="#">
                      <img src="img/square-photos/3.jpg" class="img-responsive">
                    </a>
                  </div>
                  <div class="col-xs-3">
                    <a href="#">
                      <img src="img/square-photos/4.jpg" class="img-responsive">
                    </a>
                  </div>
                </div>
                <div class="row gutter-sm">
                  <div class="col-xs-3">
                    <a href="#">
                      <img src="img/square-photos/5.jpg" class="img-responsive">
                    </a>
                  </div>
                  <div class="col-xs-3">
                    <a href="#">
                      <img src="img/square-photos/6.jpg" class="img-responsive">
                    </a>
                  </div>
                  <div class="col-xs-3">
                    <a href="#">
                      <img src="img/square-photos/7.jpg" class="img-responsive">
                    </a>
                  </div>
                  <div class="col-xs-3">
                    <a href="#">
                      <img src="img/square-photos/8.jpg" class="img-responsive">
                    </a>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-4">
            <div class="panel panel-default panel-table">
              <div class="panel-heading">
                <div class="panel-tools">
                  <a href="#" class="tools-icon">
                    <i class="zmdi zmdi-refresh"></i>
                  </a>
                  <a href="#" class="tools-icon">
                    <i class="zmdi zmdi-close"></i>
                  </a>
                </div>
                <h3 class="panel-title">Keywords</h3>
                <div class="panel-subtitle">+23% from previous period</div>
              </div>
              <div class="table-responsive">
                <table class="table table-borderless table-condensed m-b-0">
                  <tbody>
                    <tr>
                      <td class="col-xs-1">1.</td>
                      <td class="col-xs-3">
                        app design
                      </td>
                      <td class="col-xs-3">
                        <div class="text-right text-truncate">42 366
                          <i class="zmdi zmdi-arrow-left-bottom"></i>
                        </div>
                      </td>
                      <td class="col-xs-5">
                        <div class="progress progress-xs m-t-20">
                          <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="width: 70%">
                            <span class="sr-only">70% Complete (success)</span>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td class="col-xs-1">2.</td>
                      <td class="col-xs-3">
                        development
                      </td>
                      <td class="col-xs-3">
                        <div class="text-right text-truncate">35 456
                          <i class="zmdi zmdi-arrow-left-bottom"></i>
                        </div>
                      </td>
                      <td class="col-xs-5">
                        <div class="progress progress-xs m-t-20">
                          <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="57" aria-valuemin="0" aria-valuemax="100" style="width: 57%">
                            <span class="sr-only">57% Complete (success)</span>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td class="col-xs-1">3.</td>
                      <td class="col-xs-3">
                        freebies
                      </td>
                      <td class="col-xs-3">
                        <div class="text-right text-truncate">17 020
                          <i class="zmdi zmdi-arrow-right-top"></i>
                        </div>
                      </td>
                      <td class="col-xs-5">
                        <div class="progress progress-xs m-t-20">
                          <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100" style="width: 25%">
                            <span class="sr-only">25% Complete (success)</span>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td class="col-xs-1">4.</td>
                      <td class="col-xs-3">
                        portfolio
                      </td>
                      <td class="col-xs-3">
                        <div class="text-right text-truncate">5 450
                          <i class="zmdi zmdi-arrow-left-bottom"></i>
                        </div>
                      </td>
                      <td class="col-xs-5">
                        <div class="progress progress-xs m-t-20">
                          <div class="progress-bar progress-bar-warning" role="progressbar" aria-valuenow="40" aria-valuemin="0" aria-valuemax="100" style="width: 40%">
                            <span class="sr-only">40% Complete (success)</span>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td class="col-xs-1">5.</td>
                      <td class="col-xs-3">
                        agency
                      </td>
                      <td class="col-xs-3">
                        <div class="text-right text-truncate">2 398
                          <i class="zmdi zmdi-arrow-right-top"></i>
                        </div>
                      </td>
                      <td class="col-xs-5">
                        <div class="progress progress-xs m-t-20">
                          <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                            <span class="sr-only">80% Complete (success)</span>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td class="col-xs-1">6.</td>
                      <td class="col-xs-3">
                        material
                      </td>
                      <td class="col-xs-3">
                        <div class="text-right text-truncate">1 470
                          <i class="zmdi zmdi-arrow-right-top"></i>
                        </div>
                      </td>
                      <td class="col-xs-5">
                        <div class="progress progress-xs m-t-20">
                          <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="33" aria-valuemin="0" aria-valuemax="100" style="width: 33%">
                            <span class="sr-only">33% Complete (success)</span>
                          </div>
                        </div>
                      </td>
                    </tr>
                    <tr>
                      <td class="col-xs-1">7.</td>
                      <td class="col-xs-3">
                        flat
                      </td>
                      <td class="col-xs-3">
                        <div class="text-right text-truncate">780
                          <i class="zmdi zmdi-arrow-right-top"></i>
                        </div>
                      </td>
                      <td class="col-xs-5">
                        <div class="progress progress-xs m-t-20">
                          <div class="progress-bar progress-bar-danger" role="progressbar" aria-valuenow="50" aria-valuemin="0" aria-valuemax="100" style="width: 50%">
                            <span class="sr-only">50% Complete (success)</span>
                          </div>
                        </div>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="panel panel-default panel-table">
              <div class="panel-heading">
                <div class="panel-tools">
                  <a href="#" class="tools-icon">
                    <i class="zmdi zmdi-refresh"></i>
                  </a>
                  <a href="#" class="tools-icon">
                    <i class="zmdi zmdi-close"></i>
                  </a>
                </div>
                <h3 class="panel-title">Activity</h3>
                <div class="panel-subtitle">+58% from previous period</div>
              </div>
              <div class="panel-body">
                <div class="widget-activity">
                  <div class="wa-item">
                    <div class="wai-icon bg-success">
                      <i class="zmdi zmdi-account"></i>
                    </div>
                    <div class="m-b-5"><a href="#" class="text-primary">John Doe</a> is now following <a href="#" class="text-primary">Kate Morris</a>.</div>
                    <div class="wai-time">10 min</div>
                  </div>
                  <div class="wa-item">
                    <div class="wai-icon bg-warning">
                      <i class="zmdi zmdi-favorite"></i>
                    </div>
                    <div class="m-b-5"><a href="#" class="text-primary">Alexander Olsen</a> liked post <a href="#" class="text-primary">Getting Started with SASS</a>.</div>
                    <div class="wai-time">40 min</div>
                  </div>
                  <div class="wa-item">
                    <div class="wai-icon bg-info">
                      <i class="zmdi zmdi-comment-alt-text"></i>
                    </div>
                    <div class="m-b-5"><a href="#" class="text-primary">Linda Davis</a> commented post <a href="#" class="text-primary">How to use Bower</a>.</div>
                    <div class="wai-time">3 hours</div>
                  </div>
                  <div class="wa-item">
                    <div class="wai-icon bg-success">
                      <i class="zmdi zmdi-account"></i>
                    </div>
                    <div class="m-b-5"><a href="#" class="text-primary">John Doe</a> is now following <a href="#" class="text-primary">Kate Morris</a>.</div>
                    <div class="wai-time">10 min</div>
                  </div>
                  <div class="wa-item">
                    <div class="wai-icon bg-warning">
                      <i class="zmdi zmdi-favorite"></i>
                    </div>
                    <div class="m-b-5"><a href="#" class="text-primary">Alexander Olsen</a> liked post <a href="#" class="text-primary">Getting Started with SASS</a>.</div>
                    <div class="wai-time">40 min</div>
                  </div>
                </div>
                <button type="button" class="btn btn-primary btn-block">Load more</button>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="panel panel-default panel-table">
              <div class="panel-heading">
                <div class="panel-tools">
                  <a href="#" class="tools-icon">
                    <i class="zmdi zmdi-refresh"></i>
                  </a>
                  <a href="#" class="tools-icon">
                    <i class="zmdi zmdi-close"></i>
                  </a>
                </div>
                <h3 class="panel-title">Top 5</h3>
                <div class="panel-subtitle">30 Jun 2017 - 17 Jul 2017</div>
              </div>
              <div class="table-responsive">
                <table class="table table-borderless">
                  <tbody>
                    <tr>
                      <td>
                        <img class="img-circle" src="img/avatars/male.png" alt="" width="32" height="32">
                      </td>
                      <td>
                        Jonathan Mel
                        <br>
                        <small class="text-muted">
                          <span class="flag-icon flag-icon-us"></span> USA</small>
                      </td>
                      <td>
                        <div class="text-warning">
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                        </div>
                      </td>
                      <td class="actions text-center">
                        <a href="#">
                          <i class="zmdi zmdi-more"></i>
                        </a>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <img class="img-circle" src="img/avatars/female.png" alt="" width="32" height="32">
                      </td>
                      <td>
                        Landon Graham
                        <br>
                        <small class="text-muted">
                          <span class="flag-icon flag-icon-no"></span> Norway</small>
                      </td>
                      <td>
                        <div class="text-warning">
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                        </div>
                      </td>
                      <td class="actions text-center">
                        <a href="#">
                          <i class="zmdi zmdi-more"></i>
                        </a>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <img class="img-circle" src="img/avatars/male.png" alt="" width="32" height="32">
                      </td>
                      <td>
                        Ron Carran
                        <br>
                        <small class="text-muted">
                          <span class="flag-icon flag-icon-fr"></span> France</small>
                      </td>
                      <td>
                        <div class="text-warning">
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star-outline"></i>
                        </div>
                      </td>
                      <td class="actions text-center">
                        <a href="#">
                          <i class="zmdi zmdi-more"></i>
                        </a>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <img class="img-circle" src="img/avatars/female.png" alt="" width="32" height="32">
                      </td>
                      <td>
                        Lucius Skyler
                        <br>
                        <small class="text-muted">
                          <span class="flag-icon flag-icon-de"></span> Germany</small>
                      </td>
                      <td>
                        <div class="text-warning">
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star-outline"></i>
                          <i class="zmdi zmdi-star-outline"></i>
                        </div>
                      </td>
                      <td class="actions text-center">
                        <a href="#">
                          <i class="zmdi zmdi-more"></i>
                        </a>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <img class="img-circle" src="img/avatars/male.png" alt="" width="32" height="32">
                      </td>
                      <td>
                        Vance Osborn
                        <br>
                        <small class="text-muted">
                          <span class="flag-icon flag-icon-pl"></span> Poland</small>
                      </td>
                      <td>
                        <div class="text-warning">
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star-outline"></i>
                          <i class="zmdi zmdi-star-outline"></i>
                        </div>
                      </td>
                      <td class="actions text-center">
                        <a href="#">
                          <i class="zmdi zmdi-more"></i>
                        </a>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <img class="img-circle" src="img/avatars/female.png" alt="" width="32" height="32">
                      </td>
                      <td>
                        Angelica Ramos
                        <br>
                        <small class="text-muted">
                          <span class="flag-icon flag-icon-ru"></span> Russia</small>
                      </td>
                      <td>
                        <div class="text-warning">
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star-outline"></i>
                          <i class="zmdi zmdi-star-outline"></i>
                        </div>
                      </td>
                      <td class="actions text-center">
                        <a href="#">
                          <i class="zmdi zmdi-more"></i>
                        </a>
                      </td>
                    </tr>
                    <tr>
                      <td>
                        <img class="img-circle" src="img/avatars/male.png" alt="" width="32" height="32">
                      </td>
                      <td>
                        Brenden Wagner
                        <br>
                        <small class="text-muted">
                          <span class="flag-icon flag-icon-au"></span> Australia</small>
                      </td>
                      <td>
                        <div class="text-warning">
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star"></i>
                          <i class="zmdi zmdi-star-outline"></i>
                          <i class="zmdi zmdi-star-outline"></i>
                        </div>
                      </td>
                      <td class="actions text-center">
                        <a href="#">
                          <i class="zmdi zmdi-more"></i>
                        </a>
                      </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
<!---->
	  
<!--Add Footer Web Part Here-->
<?php include('webparts/footer.php'); ?>
<!---->