<?php
 function getext($img){
  $name = strtolower($img);
  $data = explode(".", $name);
  $ext = count($data) -1;
  return $data[$ext];
 }
 if(isset($_FILES)){
  $allowed = array('jpg','png','gif');
  $ext = getext($_FILES['file1']['name']);
  $size = $_FILES['file1']['size'];
  if(in_array($ext, $allowed)){
   if($size < 20971522){
    $name = $_FILES['file1']['name'];
	
	$temp = explode(".", $_FILES['file1']['name']);
    $newfilename = round(microtime(true)) . '.' . end($temp);
	
    if(move_uploaded_file($_FILES['file1']['tmp_name'], './upload/'.$newfilename)){
     
    }else{
     //file upload has an error
    }
   }else{
    //File size more than <strong>20MB<strong>"
   }
  }else{
   //file type not allowed
  }
 }else{
  //
 }
?>