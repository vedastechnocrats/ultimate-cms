<!--Add Header Web Part Here-->
<?php include('webparts/header.php'); ?>
<!---->	

<!--Add Sidebar Web Part Here-->
<?php include('webparts/sidebar.php'); ?>
<!---->	
	  
<!--Website Content goes here--> 
      <div class="site-content">
        <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Chart.js</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-6 m-b-30">
                <h4 class="m-t-0 m-b-30">Line chart</h4>
                <canvas id="line" style="height: 300px"></canvas>
              </div>
              <div class="col-md-6 m-b-30">
                <h4 class="m-t-0 m-b-30">Bar chart</h4>
                <canvas id="bar" style="height: 300px"></canvas>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 m-b-30">
                <h4 class="m-t-0 m-b-30">Pie chart</h4>
                <canvas id="pie" style="height: 300px"></canvas>
              </div>
              <div class="col-md-6 m-b-30">
                <h4 class="m-t-0 m-b-30">Doughnut chart</h4>
                <canvas id="doughnut" style="height: 300px"></canvas>
              </div>
            </div>
            <div class="row">
              <div class="col-md-6 m-b-30">
                <h4 class="m-t-0 m-b-30">Polar area chart</h4>
                <canvas id="polar-area" style="height: 300px"></canvas>
              </div>
              <div class="col-md-6 m-b-30">
                <h4 class="m-t-0 m-b-30">Radar chart</h4>
                <canvas id="radar" style="height: 300px"></canvas>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!---->
	  
<!--Add Footer Web Part Here-->
<?php include('webparts/footer.php'); ?>
<!---->