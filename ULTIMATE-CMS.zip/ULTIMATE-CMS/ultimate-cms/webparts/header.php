<?php require ('webconfig/config.php'); ?>

<?php
session_start();
	//Check whether the session variable SESS_MEMBER_ID is present or not
	if(!isset($_SESSION['SESSUCADMIN_MEMBER_ID']) || (trim($_SESSION['SESSUCADMIN_MEMBER_ID']) == '')) {
		
		
		//Session is not Activate Logged in using Cookie
		@$uname=$_COOKIE['ucadminusername'];
        @$password=$_COOKIE['ucadminpassword'];
		
		if(empty($uname)){
			?>
			<script>
	        location.replace("<?php echo $base_url; ?>/login/?status=loginagain");
	        </script>
			<?php
		}
	}else{
		//Session is Activate Logged in using Session
		
	}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <meta name="description" content="">
    <title>Ultimate CMS</title>
    <link rel="icon" type="image/png" href="<?php echo $base_url; ?>/favicon-32x32.png" sizes="32x32">
    <link rel="icon" type="image/png" href="<?php echo $base_url; ?>/favicon-16x16.png" sizes="16x16">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700" rel="stylesheet">
	<link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/vendor.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/cosmos.min.css">
    <link rel="stylesheet" href="<?php echo $base_url; ?>/css/application.min.css">
	<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">
	<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
	<link rel="stylesheet" href="<?php echo $base_url; ?>/css/timepicker.css">
	<link rel="stylesheet" href="<?php echo $base_url; ?>/css/style.css">
	<link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/css/toastr.min.css" rel="stylesheet">
	<script type="text/javascript">
    	var url = "<?php echo $base_url; ?>/";
    </script>
	<!--For Video Player-->
	<link href="http://vjs.zencdn.net/vjs-version/video-js.css" rel="stylesheet">

    <!-- If you'd like to support IE8 -->
    <script src="http://vjs.zencdn.net/ie8/ie8-version/videojs-ie8.min.js"></script>
  
</head>
  <body class="layout layout-header-fixed layout-left-sidebar-fixed">
    <div class="site-overlay"></div>
    <div class="site-header">
      <nav class="navbar navbar-default">
        <div class="navbar-header">
          <a class="navbar-brand" href="index-2.html">
            <img src="<?php echo $base_url; ?>/img/logo.png" alt="" height="25">
            <span>Ultimate CMS</span>
          </a>
          <button class="navbar-toggler left-sidebar-toggle pull-left visible-xs" type="button">
            <span class="hamburger"></span>
          </button>
        </div>
        <div class="navbar-collapsible">
          <div id="navbar" class="navbar-collapse collapse">
            <button class="navbar-toggler left-sidebar-collapse pull-left hidden-xs" type="button">
              <span class="hamburger"></span>
            </button>
            <ul class="nav navbar-nav">
              <li class="visible-xs-block">
                <div class="nav-avatar">
                  <img class="img-circle" src="<?php echo $base_url; ?>/img/avatars/1.jpg" alt="" width="48" height="48">
                </div>
                <h4 class="navbar-text text-center">Welcome, Jon Snow!</h4>
              </li>
            </ul>
            <form class="navbar-form navbar-left">
              <div class="navbar-search-group">
                <input type="text" class="form-control" placeholder="Search">
                <button type="submit" class="btn btn-default">
                  <i class="zmdi zmdi-search"></i>
                </button>
              </div>
            </form>
            <ul class="nav navbar-nav navbar-right">
              <li class="nav-table dropdown visible-xs-block">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                  <span class="nav-cell nav-icon">
                    <i class="zmdi zmdi-account-o"></i>
                  </span>
                  <span class="hidden-md-up m-l-15">Account</span>
                </a>
                <ul class="dropdown-menu">
                  <li><a href="<?php echo $base_url; ?>/profile/">Profile</a></li>
                  <li><a href="#" data-toggle="modal" data-target="#settingsModal">Settings</a></li>
                  <li><a href="#">Help</a></li>
                  <li role="separator" class="divider"></li>
                  <li><a href="<?php echo $base_url; ?>/logout.php">Logout</a></li>
                </ul>
              </li>
              <li class="nav-table dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                  <span class="nav-cell nav-icon">
                    <i class="zmdi zmdi-apps"></i>
                  </span>
                  <span class="hidden-md-up m-l-15">Applications</span>
                </a>
                <div class="dropdown-menu dropdown-apps custom-dropdown">
                  <div class="a-area">
                    <div class="row gutter-xs">
                      <div class="col-xs-4">
                        <div class="a-item">
                          <a href="#">
                            <div class="ai-icon">
                              <img class="img-responsive" src="<?php echo $base_url; ?>/img/brands/dropbox.png" alt="">
                            </div>
                            <div class="ai-title">Dropbox</div>
                          </a>
                        </div>
                      </div>
                      <div class="col-xs-4">
                        <div class="a-item">
                          <a href="#">
                            <div class="ai-icon">
                              <img class="img-responsive" src="<?php echo $base_url; ?>/img/brands/github.png" alt="">
                            </div>
                            <div class="ai-title">Github</div>
                          </a>
                        </div>
                      </div>
                      <div class="col-xs-4">
                        <div class="a-item">
                          <a href="#">
                            <div class="ai-icon">
                              <img class="img-responsive" src="<?php echo $base_url; ?>/img/brands/drive.png" alt="">
                            </div>
                            <div class="ai-title">Drive</div>
                          </a>
                        </div>
                      </div>
                     </div>
                  </div>
                </div>
              </li>
              <li class="nav-table dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                  <span class="nav-cell nav-icon">
                    <i class="zmdi zmdi-notifications-none"></i>
                  </span>
                  <span class="hidden-md-up m-l-15">Notifications</span>
                  <span class="label label-success">3</span>
                </a>
                <div class="dropdown-menu custom-dropdown dropdown-notifications dropdown-menu-right">
                  <div class="dropdown-header">
                    <span>Notifications</span>
                    <a href="#" class="text-primary">Mark all as read</a>
                  </div>
                  <div class="n-items">
                    <div class="custom-scrollbar">
                      <div class="n-item">
                        <div class="ni-img">
                          <img class="img-circle" src="<?php echo $base_url; ?>/img/avatars/female.png" alt="" width="40" height="40">
                        </div>
                        <div class="ni-text"><a href="#">John Doe</a> is now following <a href="#">Kate Morris</a>.</div>
                        <div class="ni-time">10 min</div>
                      </div>
                      <div class="n-item">
                        <div class="ni-img">
                          <img class="img-circle" src="<?php echo $base_url; ?>/img/avatars/male.png" alt="" width="40" height="40">
                        </div>
                        <div class="ni-text"><a href="#">Alexander Olsen</a> liked post <a href="#">Getting Started with SASS</a>.</div>
                        <div class="ni-time">40 min</div>
                      </div>
                      <div class="n-item">
                        <div class="ni-img">
                          <img class="img-circle" src="<?php echo $base_url; ?>/img/avatars/female.png" alt="" width="40" height="40">
                        </div>
                        <div class="ni-text"><a href="#">Linda Davis</a> commented post <a href="#">How to use Bower</a>.</div>
                        <div class="ni-time">3 hours</div>
                      </div>
                      <div class="n-item">
                        <div class="ni-img">
                          <img class="img-circle" src="<?php echo $base_url; ?>/img/avatars/male.png" alt="" width="40" height="40">
                        </div>
                        <div class="ni-text"><a href="#">John Doe</a> is now following <a href="#">Kate Morris</a>.</div>
                        <div class="ni-time">10 min</div>
                      </div>
                      <div class="n-item">
                        <div class="ni-img">
                          <img class="img-circle" src="<?php echo $base_url; ?>/img/avatars/male.png" alt="" width="40" height="40">
                        </div>
                        <div class="ni-text"><a href="#">Alexander Olsen</a> liked post <a href="#">Getting Started with SASS</a>.</div>
                        <div class="ni-time">40 min</div>
                      </div>
                      <div class="n-item">
                        <div class="ni-img">
                          <img class="img-circle" src="<?php echo $base_url; ?>/img/avatars/female.png" alt="" width="40" height="40">
                        </div>
                        <div class="ni-text"><a href="#">Linda Davis</a> commented post <a href="#">How to use Bower</a>.</div>
                        <div class="ni-time">3 hours</div>
                      </div>
                    </div>
                  </div>
                  <div class="dropdown-footer">
                    <a href="#">View all notifications</a>
                  </div>
                </div>
              </li>
              <li class="nav-table dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                  <span class="nav-cell nav-icon">
                    <i class="zmdi zmdi-email-open"></i>
                  </span>
                  <span class="hidden-md-up m-l-15">Messages</span>
                  <span class="label label-warning">7</span>
                </a>
                <div class="dropdown-menu custom-dropdown dropdown-messages dropdown-menu-right">
                  <div class="dropdown-header">
                    <span>Recent messages</span>
                    <a href="#" class="text-primary">New Message</a>
                  </div>
                  <div class="m-items">
                    <div class="custom-scrollbar">
                      <div class="m-item">
                        <a href="#">
                          <div class="mi-icon bg-warning">
                            <i class="zmdi zmdi-upload"></i>
                          </div>
                          <div class="mi-time">10 min</div>
                          <div class="mi-title">Upload status</div>
                          <div class="mi-text text-truncate">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</div>
                        </a>
                      </div>
                      <div class="m-item">
                        <a href="#">
                          <div class="mi-icon bg-success">
                            <i class="zmdi zmdi-money"></i>
                          </div>
                          <div class="mi-time">40 min</div>
                          <div class="mi-title">Income</div>
                          <div class="mi-text text-truncate">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</div>
                        </a>
                      </div>
                      <div class="m-item">
                        <a href="#">
                          <div class="mi-icon bg-primary">
                            <i class="zmdi zmdi-alert-triangle"></i>
                          </div>
                          <div class="mi-time">3 hours</div>
                          <div class="mi-title">New task</div>
                          <div class="mi-text text-truncate">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</div>
                        </a>
                      </div>
                      <div class="m-item">
                        <a href="#">
                          <div class="mi-icon bg-warning">
                            <i class="zmdi zmdi-upload"></i>
                          </div>
                          <div class="mi-time">10 min</div>
                          <div class="mi-title">Upload status</div>
                          <div class="mi-text text-truncate">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</div>
                        </a>
                      </div>
                      <div class="m-item">
                        <a href="#">
                          <div class="mi-icon bg-success">
                            <i class="zmdi zmdi-money"></i>
                          </div>
                          <div class="mi-time">40 min</div>
                          <div class="mi-title">Income</div>
                          <div class="mi-text text-truncate">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</div>
                        </a>
                      </div>
                      <div class="m-item">
                        <a href="#">
                          <div class="mi-icon bg-primary">
                            <i class="zmdi zmdi-alert-triangle"></i>
                          </div>
                          <div class="mi-time">3 hours</div>
                          <div class="mi-title">New task</div>
                          <div class="mi-text text-truncate">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</div>
                        </a>
                      </div>
                    </div>
                  </div>
                  <div class="dropdown-footer">
                    <a href="#">View all messages</a>
                  </div>
                </div>
              </li>
              <li class="nav-table dropdown hidden-sm-down">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                  <span class="nav-cell p-r-10">
                    <img class="img-circle" src="<?php echo $base_url; ?>/img/avatars/usericon.png" alt="" width="32" height="32">
                  </span>
                  <span class="nav-cell">Jon Snow
                    <span class="caret"></span>
                  </span>
                </a>
                <ul class="dropdown-menu">
                  <li>
                    <a href="<?php echo $base_url; ?>/profile/">
                      <i class="zmdi zmdi-account-o m-r-10"></i> Profile</a>
                  </li>
                  <li>
                    <a href="#"  data-toggle="modal" data-target="#settingsModal">
                      <i class="zmdi zmdi-settings m-r-10"></i> Settings</a>
                  </li>
                  <li>
                    <a href="<?php echo $base_url; ?>/help/">
                      <i class="zmdi zmdi-help-outline m-r-10"></i> Help</a>
                  </li>
                  <li role="separator" class="divider"></li>
                  <li>
                    <a href="<?php echo $base_url; ?>/logout.php">
                      <i class="zmdi zmdi-power m-r-10"></i> Logout</a>
                  </li>
                </ul>
              </li>
            </ul>
          </div>
        </div>
      </nav>
    </div>
	
	            <!--Settings Modal-->
	            <div id="settingsModal" class="modal fade" tabindex="-1" role="dialog">
                  <div class="modal-dialog">
                    <div class="modal-content">
                      <div class="modal-header bg-info">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                          <span aria-hidden="true">
                            <i class="zmdi zmdi-close"></i>
                          </span>
                        </button>
                        <h4 class="modal-title">Settings</h4>
                      </div>
                      <div class="modal-body">
                              <div class="panel panel-default">
          <div class="panel-heading">
            <h3 class="m-y-0">Custom form elements</h3>
          </div>
          <div class="panel-body">
            <div class="row">
              <div class="col-md-8">
                <form class="form-horizontal">
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-21">Custom select</label>
                    <div class="col-sm-9">
                      <select id="form-control-21" class="custom-select">
                        <option value="" selected="selected">Day of the week</option>
                        <option value="1">Monday</option>
                        <option value="2">Tuesday</option>
                        <option value="3">Wednesday</option>
                        <option value="4">Thursday</option>
                        <option value="5">Friday</option>
                        <option value="6">Saturday</option>
                        <option value="7">Sunday</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label" for="form-control-22">Custom file inputs</label>
                    <div class="col-sm-9">
                      <label class="btn btn-default file-upload-btn">
                        Choose file...
                        <input id="form-control-22" class="file-upload-input" type="file" name="files[]" multiple="multiple">
                      </label>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-9 col-sm-offset-3">
                      <div class="input-group">
                        <input class="form-control" type="text" placeholder="Choose file...">
                        <span class="input-group-btn">
                          <label class="btn btn-primary file-upload-btn">
                            <input class="file-upload-input" type="file" name="file">
                            <i class="zmdi zmdi-attachment-alt"></i>
                          </label>
                        </span>
                      </div>
                      <p class="help-block">
                        <small>Click the button next to the input field.</small>
                      </p>
                    </div>
                  </div>
                  <div class="form-group m-b-20">
                    <label class="col-sm-3 control-label">Custom checkboxes</label>
                    <div class="col-sm-9">
                      <div class="custom-controls-stacked">
                        <label class="custom-control custom-control-default custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Default</span>
                        </label>
                        <label class="custom-control custom-control-primary custom-checkbox active">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Primary</span>
                        </label>
                        <label class="custom-control custom-control-success custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Success</span>
                        </label>
                        <label class="custom-control custom-control-info custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Info</span>
                        </label>
                        <label class="custom-control custom-control-warning custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Warning</span>
                        </label>
                        <label class="custom-control custom-control-danger custom-checkbox">
                          <input class="custom-control-input" type="checkbox" name="custom" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Danger</span>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group m-b-20">
                    <label class="col-sm-3 control-label">Custom checkboxes validation states</label>
                    <div class="col-sm-9">
                      <div class="custom-controls-stacked">
                        <label class="custom-control custom-control-success custom-checkbox has-success">
                          <input class="custom-control-input" type="checkbox" name="validation">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">With success</span>
                        </label>
                        <label class="custom-control custom-control-warning custom-checkbox has-warning">
                          <input class="custom-control-input" type="checkbox" name="validation">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">With warning</span>
                        </label>
                        <label class="custom-control custom-control-danger custom-checkbox has-error">
                          <input class="custom-control-input" type="checkbox" name="validation">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">With error</span>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group m-b-20">
                    <label class="col-sm-3 control-label">Button checkboxes</label>
                    <div class="col-sm-9">
                      <div class="btn-group" data-toggle="buttons">
                        <label class="btn btn-default">
                          <input type="checkbox" name="buttonCheckboxes" autocomplete="off"> PHP
                        </label>
                        <label class="btn btn-default">
                          <input type="checkbox" name="buttonCheckboxes" autocomplete="off"> Ruby
                        </label>
                        <label class="btn btn-default">
                          <input type="checkbox" name="buttonCheckboxes" autocomplete="off"> Python
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group m-b-20">
                    <label class="col-sm-3 control-label">Switches</label>
                    <div class="col-sm-9">
                      <div class="switches-stacked">
                        <label class="switch">
                          <input type="checkbox" name="switches" class="s-input">
                          <span class="s-content">
                            <span class="s-track"></span>
                            <span class="s-handle"></span>
                          </span>
                        </label>
                        <label class="switch switch-primary">
                          <input type="checkbox" name="switches" class="s-input" checked="checked">
                          <span class="s-content">
                            <span class="s-track"></span>
                            <span class="s-handle"></span>
                          </span>
                        </label>
                        <label class="switch switch-success">
                          <input type="checkbox" name="switches" class="s-input" checked="checked">
                          <span class="s-content">
                            <span class="s-track"></span>
                            <span class="s-handle"></span>
                          </span>
                        </label>
                        <label class="switch switch-info">
                          <input type="checkbox" name="switches" class="s-input" checked="checked">
                          <span class="s-content">
                            <span class="s-track"></span>
                            <span class="s-handle"></span>
                          </span>
                        </label>
                        <label class="switch switch-warning">
                          <input type="checkbox" name="switches" class="s-input" checked="checked">
                          <span class="s-content">
                            <span class="s-track"></span>
                            <span class="s-handle"></span>
                          </span>
                        </label>
                        <label class="switch switch-danger">
                          <input type="checkbox" name="switches" class="s-input" checked="checked">
                          <span class="s-content">
                            <span class="s-track"></span>
                            <span class="s-handle"></span>
                          </span>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-sm-3 control-label">Custom radios</label>
                    <div class="col-sm-9">
                      <div class="custom-controls-stacked">
                        <label class="custom-control custom-control-primary custom-radio">
                          <input class="custom-control-input" type="radio" name="period" value="day">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Day</span>
                        </label>
                        <label class="custom-control custom-control-primary custom-radio">
                          <input class="custom-control-input" type="radio" name="period" value="week" checked="checked">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Week</span>
                        </label>
                        <label class="custom-control custom-control-primary custom-radio">
                          <input class="custom-control-input" type="radio" name="period" value="month">
                          <span class="custom-control-indicator"></span>
                          <span class="custom-control-label">Month</span>
                        </label>
                      </div>
                    </div>
                  </div>
                  <div class="form-group m-b-20">
                    <label class="col-sm-3 control-label">Button radios</label>
                    <div class="col-sm-9">
                      <div class="btn-group" data-toggle="buttons">
                        <label class="btn btn-outline-primary active">
                          <input type="radio" name="buttonRadios" id="buttonRadios1" autocomplete="off" checked="checked"> PHP
                        </label>
                        <label class="btn btn-outline-primary">
                          <input type="radio" name="buttonRadios" id="buttonRadios2" autocomplete="off"> Ruby
                        </label>
                        <label class="btn btn-outline-primary">
                          <input type="radio" name="buttonRadios" id="buttonRadios3" autocomplete="off"> Python
                        </label>
                      </div>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
					  </div>
                      <div class="modal-footer">
                        <button type="button" data-dismiss="modal" class="btn btn-info">Continue</button>
                        <button type="button" data-dismiss="modal" class="btn btn-default">Close</button>
                      </div>
                    </div>
                  </div>
                </div>
				<!-- -->
