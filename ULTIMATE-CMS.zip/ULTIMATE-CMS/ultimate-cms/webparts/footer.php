<!--This part is the footer of the application-->
<div class="site-footer">
<!--Change the footer text as per the requirements-->
        <?php echo date('Y'); ?> © Ultimate CMS - A <a href="https://vedastechnocrats.in" target="_blank">Vedas Technocrats</a> Product
      </div>
    </div>
    <script src="<?php echo $base_url; ?>/js/vendor.min.js"></script>
    <script src="<?php echo $base_url; ?>/js/cosmos.min.js"></script>
    <script src="<?php echo $base_url; ?>/js/application.min.js"></script>
    <script src="<?php echo $base_url; ?>/js/dashboard-2.min.js"></script>
	<script src="<?php echo $base_url; ?>/js/tables-datatables.min.js"></script>
	<!--Charts are controlled from here using chartjs-->
	<script >
	"use strict";
! function(a) {
    var b = {
		//Change the Labels as per the requirements
        labels: ["January", "February", "March", "April", "May", "June", "July"],
        datasets: [{
			//Chart of what
            label: "Registartions",
            fill: !1,
            lineTension: 0,
            backgroundColor: "#e53935",
            borderColor: "#e53935",
            borderCapStyle: "butt",
            borderDash: [],
            borderDashOffset: 0,
            borderJoinStyle: "miter",
            pointBorderColor: "#e53935",
            pointBackgroundColor: "#fff",
            pointBorderWidth: 1,
            pointHoverRadius: 5,
            pointHoverBackgroundColor: "#e53935",
            pointHoverBorderColor: "#fff",
            pointHoverBorderWidth: 2,
            pointRadius: 1,
            pointHitRadius: 10,
			//Change the value as per the need
			//This will remove the comma which will generate by the the dynamically generated character in the string
            data: [<?php echo substr('20, 60, 40, 95, 40, 55, 120,', 0, -1); ?>],
            spanGaps: !1
        }]
    };
    new Chart(a("#line"), {
        type: "line",
        data: b,
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: !0
                    }
                }]
            }
        }
    });
    var c = {
		//Change the Labels as per the requirements
        labels: ["January", "February", "March", "April", "May", "June", "July"],
        datasets: [{
			//Chart of what
            label: "Sales",
			//Change the value as per the need
            data: [20, 28, 16, 10, 23, 18, 35],
            backgroundColor: "rgba(67, 185, 104, 0.2)",
            borderColor: "#34a853",
            borderWidth: 1
        }]
    };
    new Chart(a("#bar"), {
        type: "bar",
        data: c,
        options: {
            scales: {
                yAxes: [{
                    ticks: {
                        beginAtZero: !0
                    }
                }]
            }
        }
    });
    var d = {
		//Change the Labels as per the requirements
        labels: ["Apple", "Samsung", "LG"],
        datasets: [{
			//Change the value as per the need
            data: [250, 70, 160],
            backgroundColor: ["#1d87e4", "#faa800", "#e53935"]
        }]
    };
    new Chart(a("#pie"), {
        type: "pie",
        data: d
    });
    var e = {
		//Change the Labels as per the requirements
        labels: ["Apple", "Samsung", "LG"],
        datasets: [{
			//Change the value as per the need
            data: [250, 70, 160],
            backgroundColor: ["#1d87e4", "#faa800", "#e53935"]
        }]
    };
    new Chart(a("#doughnut"), {
        type: "doughnut",
        data: e
    });
    var f = {
        datasets: [{
			//Change the value as per the need
            data: [11, 25, 17, 8, 30],
            backgroundColor: ["#e53935", "#34a853", "#faa800", "#777"]
        }],
		//Change the Labels as per the requirements
        labels: ["Red", "Green", "Orange", "Grey"]
    };
    new Chart(a("#polar-area"), {
        type: "polarArea",
        data: f
    });
    var g = {
		//Change the Labels as per the requirements
        labels: ["Eating", "Drinking", "Sleeping", "Designing", "Coding", "Cycling", "Running"],
        datasets: [{
            label: "2015",
            backgroundColor: "rgba(244,66,54,0.2)",
            borderColor: "#e53935",
            pointBackgroundColor: "#e53935",
            pointBorderColor: "#fff",
            pointHoverBackgroundColor: "#fff",
            pointHoverBorderColor: "#e53935",
			//Change the value as per the need
            data: [65, 59, 90, 81, 56, 55, 40]
        }, {
            label: "2016",
            backgroundColor: "rgba(153,153,153,0.2)",
            borderColor: "999",
            pointBackgroundColor: "999",
            pointBorderColor: "#fff",
            pointHoverBackgroundColor: "#fff",
            pointHoverBorderColor: "#999",
			//Change the value as per the need
            data: [28, 48, 40, 19, 96, 27, 100]
        }]
    };
    new Chart(a("#radar"), {
        type: "radar",
        data: g
    })
}(jQuery);
	</script>
	<!-- -->
	<script src="<?php echo $base_url; ?>/js/forms-form-masks.min.js"></script>
	<script src="<?php echo $base_url; ?>/js/forms-form-wizard.min.js"></script>
	<script src="<?php echo $base_url; ?>/js/forms-material-form.min.js"></script>
	<script src="<?php echo $base_url; ?>/js/forms-plugins.min.js"></script>
	<script src="<?php echo $base_url; ?>/js/ckeditor/ckeditor.js"></script>
	<script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/twbs-pagination/1.3.1/jquery.twbsPagination.min.js"></script>
	
	<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
	<script>
      $('body').on('focus',".datepicker_recurring_start", function(){
           $(this).datepicker({dateFormat: 'yy-mm-dd'/*,minDate: new Date(2017, 07, 30),maxDate: new Date(2017, 12, 5),*//*,changeMonth: true,changeYear: true,yearRange: '1950:2013'*/
          });
       });
  </script>
  <script>
      $('body').on('focus',".timepicker_recurring_start", function(){
           $(this).timepicker({ 'scrollDefault': 'now' });
      });
  </script>
  <!--Bing Map API Integration-->
  <script type="text/javascript">
        $(document).ready(function () {
			//Specify the ID of the input searchbox
            $("#searchBox").autocomplete({
                source: function (request, response) {
                    $.ajax({
                        url: "https://dev.virtualearth.net/REST/v1/Locations",
                        dataType: "jsonp",
                        data: {
							//Change The API KEY with Your Own
                            key: "AoolQ8ulBh-_LoyAbeIm9cUeitZVVWxJuqXRlMPH756ohjHZaYEOpLH5vuv5TLlT",
                            q: request.term
                        },
                        jsonp: "jsonp",
                        success: function (data) {
                            var result = data.resourceSets[0];
                            if (result) {
                                if (result.estimatedTotal > 0) {
                                    response($.map(result.resources, function (item) {
                                        return {
                                            data: item,
                                            label: item.name + ' (' + item.address.countryRegion + ')',
                                            value: item.name
                                        }
                                    }));
                                }
                            }
                        }
                    });
                },
                minLength: 1,
                change: function (event, ui) {
                    if (!ui.item)
                        $("#searchBox").val('');
                },
                select: function (event, ui) {
                    displaySelectedItem(ui.item.data);
                }
            });
        });

		//GET the Latitude and Longitude
        function displaySelectedItem(item) {
            $("#searchResult").empty().append('Result: ' + item.name).append(' (Latitude: ' + item.point.coordinates[0] + ' Longitude: ' + item.point.coordinates[1] + ')');
        }
    </script>
	<!-- -->
	
	
	<!--AJAX Method to Insert Data of fisrt Form-->
	<script>
	$(document).ready(function () {
		 $('#using-ajax').submit(function (event) {
			 event.preventDefault();
			 $('#submit-button').css("display", "none");
			 $('#loading-button').css("display", "inline-block");
			 var form = $(this);
			 var formData = form.serialize();
			 
			 for (instance in CKEDITOR.instances) {
                CKEDITOR.instances[instance].updateElement();
            }
			 
			 $.ajax({
			 url: '<?php echo $base_url; ?>/executablefiles/addvalue1_exec.php',
			 method: 'POST',
			 data: formData,
			 success: function (data) { 
			 $('#submit-button').css("display", "block");
			 $('#loading-button').css("display", "none");
				 $('#success-alert1').css("display", "block").delay(10000).slideUp(300);
				 $("#using-ajax")[0].reset();
				 },
				 error:function (xhr, ajaxOptions, thrownError){
					 $('#submit-button').css("display", "block");
					 $('#loading-button').css("display", "none");
                $('#failed-alert1').css("display", "block").delay(10000).slideUp(300);
				$("#using-ajax")[0].reset();
                alert(thrownError);
            }
			 });
		 });
	});
</script>
	<!-- -->
	
	<!--Load the Modal in Page Load-->
	<script type="text/javascript">
		$(document).ready(function(){
			$("#statusmodal").trigger('click'); 
		});
    </script>
    <!-- -->
	
	<!--Ajax Image Upload with progress bar-->


 <script type="text/javascript">
 //Remove this if there is onclick function in the submit button
 function myFunction() {
 //
 
 
 var ajax = new XMLHttpRequest();
 function $(id){
  return document.getElementById(id);
 }
 function upload(e){
  e.preventDefault();
  var file = $("file1").files[0];
  var formdata = new FormData();
  formdata.append('file1', file);

  ajax.upload.addEventListener('progress', progressHandler, false);
  ajax.addEventListener('load', completeHandler, false);
  ajax.addEventListener('abort', abortHandler, false);
  ajax.addEventListener('error', errorHandler, false);
  ajax.open('POST', '<?php echo $base_url; ?>/upload_back.php');
  ajax.send(formdata);
 }

 //count the percentage of progress
 function progressHandler(e){
  var percent = (e.loaded / e.total) * 100;
  percent = Math.round(percent);
  //Set the percentage as width
  $('progress').style.width = Math.round(percent)+'%';
  
 }
  function completeHandler(){
   $('success-alert2').style.display = "block";
   $('progress').style.width = '100%';
  }

  function abortHandler(){
   alert('file upload aborted');
  }

  function errorHandler(){
   alert('file upload has an error');
  }
         //when form is submited
 $('ajaxfileuploadform').addEventListener('submit', upload, false);

 //Same here
 }
 //
</script>
	<!-- -->
<?php
//Check if it is ajax version or the alternate version	
if(basename($_SERVER['SCRIPT_NAME'])=="managevalue.php"){
?>
<!-- For Show, Edit and Delete from Table 1. Create another one for another table-->	
<script src="<?php echo $base_url; ?>/js/item-ajax.js"></script>
<?php	
}else{
	
}	
?>

<script>

 $(document).ready(function() {
  var date = new Date();
  var d = date.getDate();
  var m = date.getMonth();
  var y = date.getFullYear();

  var calendar = $('#calendar').fullCalendar({
   editable: true,
   header: {
    left: 'prev,next today',
    center: 'title',
    right: 'month,agendaWeek,agendaDay'
   },

   events: "<?php echo $base_url; ?>/calenderapi/events.php",

   eventRender: function(event, element, view) {
    if (event.allDay === 'true') {
     event.allDay = true;
    } else {
     event.allDay = false;
    }
   },
   selectable: true,
   selectHelper: true,
   select: function(start, end, allDay) {
   var title = prompt('Event Title:');

   if (title) {
   var start = $.fullCalendar.formatDate(start, "Y-MM-DD");
   var end = $.fullCalendar.formatDate(end, "Y-MM-DD");
   $.ajax({
	   url: '<?php echo $base_url; ?>/calenderapi/add_events.php',
	   data: 'title='+ title+'&start='+ start +'&end='+ end,
	   type: "POST",
	   success: function(json) {
	   alert('Added Successfully');
	   }
   });
   calendar.fullCalendar('renderEvent',
   {
	   title: title,
	   start: start,
	   end: end,
	   allDay: allDay
   },
   true
   );
   }
   calendar.fullCalendar('unselect');
   },

   editable: !0,
   eventLimit: !0,
   droppable: !0,
   
   eventDrop: function(event, delta) {
   var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD");
   var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD");
   $.ajax({
	   url: '<?php echo $base_url; ?>/calenderapi/update_events.php',
	   data: 'title='+ event.title+'&start='+ start +'&end='+ end +'&id='+ event.id ,
	   type: "POST",
	   success: function(json) {
	    alert("Updated Successfully");
	   }
   });
   },
   eventClick: function(event) {
	var decision = confirm("Do you really want to Delete it?"); 
	if (decision) {
	$.ajax({
		type: "POST",
		url: "<?php echo $base_url; ?>/calenderapi/delete_event.php",
		data: "&id=" + event.id,
		 success: function(json) {
			 $('#calendar').fullCalendar('removeEvents', event.id);
			  alert("Deleted Successfully");}
	});
	}
  	},
   eventResize: function(event) {
	   var start = $.fullCalendar.formatDate(event.start, "Y-MM-DD");
       var end = $.fullCalendar.formatDate(event.end, "Y-MM-DD");
	   $.ajax({
	    url: '<?php echo $base_url; ?>/calenderapi/update_event.php',
	    data: 'title='+ event.title+'&start='+ start +'&end='+ end +'&id='+ event.id ,
	    type: "POST",
	    success: function(json) {
	     alert("Updated Successfully");
	    }
	   });
	}
   
  });
  
 });

</script>
	
	<!--Google MAP API to search location-->
	<script type="text/javascript" src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA8nNGfI2eWoZsXIgOfEpBvzYZYQ4anAvs&sensor=false&libraries=places"></script>
    <script type="text/javascript">
        google.maps.event.addDomListener(window, 'load', function () {
            var places = new google.maps.places.Autocomplete(document.getElementById('txtPlaces'));
            google.maps.event.addListener(places, 'place_changed', function () {
                var place = places.getPlace();
                var address = place.formatted_address;
                var latitude = place.geometry.location.A;
                var longitude = place.geometry.location.F;
                
            });
        });
    </script>
	<!-- -->
	
	
	<!--For Video Player-->
	<script src="http://vjs.zencdn.net/6.2.5/video.js"></script>
	<!-- -->
  </body>
</html>