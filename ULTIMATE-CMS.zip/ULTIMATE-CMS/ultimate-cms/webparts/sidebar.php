<!--Dynamically Active Menu Item By checking which script is currently running-->
	<div class="site-main">
      <div class="site-left-sidebar">
        <div class="sidebar-backdrop"></div>
        <div class="custom-scrollbar">
          <ul class="sidebar-menu">
            <li class="menu-title">Main</li>
            <li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'index.php'){echo 'active'; }else { echo ''; } ?>">
              <a href="<?php echo $base_url; ?>/" >
                <span class="menu-icon">
                  <i class="zmdi zmdi-home"></i>
                </span>
                <span class="menu-text">Dashboards</span>
              </a>
            </li>
            <li class="menu-title">Components</li>
            <li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'ui-elements.php'){echo 'active'; }else { echo ''; } ?>">
              <a href="<?php echo $base_url; ?>/ui-elements/" >
                <span class="menu-icon">
                  <i class="zmdi zmdi-case"></i>
                </span>
                <span class="menu-text">UI Elements</span>
              </a>
            </li>
            <li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'addvalue.php'){echo 'active'; }else { echo ''; } ?>">
              <a href="<?php echo $base_url; ?>/addvalue/">
                <span class="menu-icon">
                  <i class="zmdi zmdi-dot-circle-alt"></i>
                </span>
                <span class="menu-text">Form</span>
              </a>
            </li>
            <li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'managevalue.php'){echo 'active'; }else { echo ''; } ?>">
              <a href="<?php echo $base_url; ?>/managevalue/">
                <span class="menu-icon">
                  <i class="zmdi zmdi-border-all"></i>
                </span>
                <span class="menu-text">Table</span>
              </a>
            </li>
            <li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'chart.php'){echo 'active'; }else { echo ''; } ?>">
              <a href="<?php echo $base_url; ?>/chart/">
                <span class="menu-icon">
                  <i class="zmdi zmdi-chart-donut"></i>
                </span>
                <span class="menu-text">Charts</span>
              </a>
            </li>
            <li class="menu-title">Pages</li>
            <li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'profile.php'){echo 'active'; }else { echo ''; } ?>">
              <a href="<?php echo $base_url; ?>/profile/">
                <span class="menu-icon">
                  <i class="zmdi zmdi-account"></i>
                </span>
                <span class="menu-text">Profile</span>
              </a>
            </li>
            <li class="with-sub <?php if(basename($_SERVER['SCRIPT_NAME']) == 'calender.php'){echo 'active'; }else { echo ''; } ?>">
              <a href="#" aria-haspopup="true">
                <span class="menu-icon">
                  <i class="zmdi zmdi-layers"></i>
                </span>
                <span class="menu-text">Other pages</span>
              </a>
              <ul class="sidebar-submenu collapse">
                <li class="menu-subtitle">Other pages</li>
                <li><a href="<?php echo $base_url; ?>/403/">403</a></li>
                <li><a href="<?php echo $base_url; ?>/404/">404</a></li>
                <li><a href="<?php echo $base_url; ?>/500/">500</a></li>
                <li class="<?php if(basename($_SERVER['SCRIPT_NAME']) == 'calender.php'){echo 'active'; }else { echo ''; } ?>"><a href="<?php echo $base_url; ?>/calender/">Calendar</a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
